(function()
{
    return function()
    {
        this.on_loadAppVariables = function()
        {		
            var obj = null;
            
			// global dataobject
		
            // global dataset
            obj = new Dataset("IAM_FMR", this);
            obj._setContents("<ColumnInfo><Column id=\"FMR_ID\" type=\"STRING\" size=\"256\"/><Column id=\"EXC_ID\" type=\"STRING\" size=\"256\"/><Column id=\"FILE_ID\" type=\"STRING\" size=\"256\"/><Column id=\"ADT_STA_DT\" type=\"STRING\" size=\"256\"/><Column id=\"ADT_END_DT\" type=\"STRING\" size=\"256\"/><Column id=\"SUB_ST\" type=\"STRING\" size=\"256\"/><Column id=\"FMR_RES\" type=\"STRING\" size=\"256\"/><Column id=\"REV_RES\" type=\"STRING\" size=\"256\"/><Column id=\"ADT_ITEM_ID\" type=\"STRING\" size=\"256\"/><Column id=\"ADT_ITEM_NM\" type=\"STRING\" size=\"256\"/><Column id=\"ACT_ISSU_ID\" type=\"STRING\" size=\"256\"/><Column id=\"PO\" type=\"STRING\" size=\"256\"/><Column id=\"PO_ACT\" type=\"STRING\" size=\"256\"/><Column id=\"ACT_DT\" type=\"STRING\" size=\"256\"/><Column id=\"IPT_DEPT_REV_CMT\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this._addDataset(obj.name, obj);


            obj = new Dataset("EDT_VALUE", this);
            obj._setContents("<ColumnInfo><Column id=\"EDIT_ID\" type=\"STRING\" size=\"256\"/><Column id=\"VALUE\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this._addDataset(obj.name, obj);


            obj = new Dataset("DEPT_CORRECTION_CNT", this);
            obj._setContents("<ColumnInfo><Column id=\"month\" type=\"STRING\" size=\"256\"/><Column id=\"IT기획부\" type=\"STRING\" size=\"256\"/><Column id=\"IT시스템운영팀\" type=\"STRING\" size=\"256\"/><Column id=\"IT정보부\" type=\"STRING\" size=\"256\"/><Column id=\"IT디지털개발부\" type=\"STRING\" size=\"256\"/><Column id=\"IT금융개발부\" type=\"STRING\" size=\"256\"/><Column id=\"IT글로벌개발팀\" type=\"STRING\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"month\">5월</Col><Col id=\"IT기획부\">1</Col><Col id=\"IT시스템운영팀\">2</Col><Col id=\"IT정보부\">9</Col><Col id=\"IT디지털개발부\">2</Col><Col id=\"IT금융개발부\">1</Col><Col id=\"IT글로벌개발팀\">5</Col></Row><Row><Col id=\"month\">6월</Col><Col id=\"IT기획부\">1</Col><Col id=\"IT시스템운영팀\">3</Col><Col id=\"IT정보부\">6</Col><Col id=\"IT디지털개발부\">10</Col><Col id=\"IT금융개발부\">3</Col><Col id=\"IT글로벌개발팀\">7</Col></Row><Row><Col id=\"month\">7월</Col><Col id=\"IT기획부\">7</Col><Col id=\"IT시스템운영팀\">6</Col><Col id=\"IT정보부\">6</Col><Col id=\"IT디지털개발부\">5</Col><Col id=\"IT금융개발부\">3</Col><Col id=\"IT글로벌개발팀\">9</Col></Row><Row><Col id=\"month\">8월</Col><Col id=\"IT기획부\">10</Col><Col id=\"IT시스템운영팀\">2</Col><Col id=\"IT정보부\">3</Col><Col id=\"IT디지털개발부\">4</Col><Col id=\"IT금융개발부\">7</Col><Col id=\"IT글로벌개발팀\">3</Col></Row><Row><Col id=\"month\">9월</Col><Col id=\"IT기획부\">5</Col><Col id=\"IT시스템운영팀\">1</Col><Col id=\"IT정보부\">8</Col><Col id=\"IT디지털개발부\">5</Col><Col id=\"IT금융개발부\">8</Col><Col id=\"IT글로벌개발팀\">10</Col></Row><Row><Col id=\"month\">10월</Col><Col id=\"IT기획부\">5</Col><Col id=\"IT시스템운영팀\">4</Col><Col id=\"IT정보부\">2</Col><Col id=\"IT디지털개발부\">5</Col><Col id=\"IT금융개발부\">5</Col><Col id=\"IT글로벌개발팀\">3</Col></Row></Rows>");
            this._addDataset(obj.name, obj);


            obj = new Dataset("MENU", this);
            obj._setContents("<ColumnInfo><Column id=\"MENU_ID\" type=\"STRING\" size=\"256\"/><Column id=\"MENU_NAME\" type=\"STRING\" size=\"256\"/><Column id=\"MENU_LEVEL\" type=\"STRING\" size=\"256\"/><Column id=\"FORM_URL\" type=\"STRING\" size=\"256\"/><Column id=\"MENU_ICON\" type=\"STRING\" size=\"256\"/><Column id=\"MENU_ENABLE\" type=\"STRING\" size=\"256\"/><Column id=\"MENU_KEY\" type=\"STRING\" size=\"256\"/><Column id=\"MENU_FLAG\" type=\"STRING\" size=\"256\"/><Column id=\"TREE_FLAG\" type=\"STRING\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"MENU_ID\">10</Col><Col id=\"MENU_NAME\">중점점검현황판</Col><Col id=\"MENU_LEVEL\">0</Col><Col id=\"MENU_ENABLE\">1</Col><Col id=\"MENU_FLAG\">1</Col><Col id=\"TREE_FLAG\">0</Col><Col id=\"FORM_URL\">Base::Dashboard.xfdl</Col></Row><Row><Col id=\"MENU_ID\">20</Col><Col id=\"MENU_NAME\">전산원장통제</Col><Col id=\"MENU_LEVEL\">0</Col><Col id=\"MENU_ENABLE\">1</Col><Col id=\"TREE_FLAG\">0</Col><Col id=\"MENU_FLAG\">1</Col><Col id=\"FORM_URL\">Base::TotalInquiry.xfdl</Col></Row><Row><Col id=\"MENU_ID\">30</Col><Col id=\"MENU_NAME\">중점감사항목관리</Col><Col id=\"MENU_LEVEL\">0</Col><Col id=\"MENU_ENABLE\">1</Col><Col id=\"TREE_FLAG\">0</Col><Col id=\"MENU_FLAG\">1</Col><Col id=\"FORM_URL\">FrameBase::Form_remoteAccessFileControl.xfdl</Col></Row><Row><Col id=\"MENU_ID\">40</Col><Col id=\"MENU_NAME\">IT사후관리</Col><Col id=\"MENU_LEVEL\">0</Col><Col id=\"MENU_ENABLE\">1</Col><Col id=\"TREE_FLAG\">0</Col><Col id=\"MENU_FLAG\">1</Col><Col id=\"FORM_URL\">Base::WorkMenualBoardList.xfdl</Col></Row><Row><Col id=\"MENU_ID\">50</Col><Col id=\"MENU_NAME\">IT감사관리</Col><Col id=\"MENU_LEVEL\">0</Col><Col id=\"MENU_ENABLE\">1</Col><Col id=\"TREE_FLAG\">0</Col><Col id=\"MENU_FLAG\">1</Col><Col id=\"FORM_URL\">FrameBase::Form_auditOrder.xfdl</Col></Row><Row><Col id=\"MENU_ID\">60</Col><Col id=\"MENU_NAME\">공통관리</Col><Col id=\"MENU_LEVEL\">0</Col><Col id=\"MENU_ENABLE\">1</Col><Col id=\"TREE_FLAG\">0</Col><Col id=\"MENU_FLAG\">1</Col></Row></Rows>");
            this._addDataset(obj.name, obj);


            obj = new Dataset("BALANCE_DISCREPANCY_CNT", this);
            obj._setContents("<ColumnInfo><Column id=\"부서\" type=\"STRING\" size=\"256\"/><Column id=\"전월\" type=\"STRING\" size=\"256\"/><Column id=\"당월\" type=\"STRING\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"부서\">IT기획부</Col><Col id=\"전월\">2</Col><Col id=\"당월\">3</Col></Row><Row><Col id=\"당월\">10</Col><Col id=\"전월\">10</Col><Col id=\"부서\">IT시스템운영팀</Col></Row><Row><Col id=\"부서\">IT정보부</Col><Col id=\"당월\">3</Col><Col id=\"전월\">7</Col></Row><Row><Col id=\"부서\">IT디지털개발부</Col><Col id=\"당월\">3</Col><Col id=\"전월\">1</Col></Row><Row><Col id=\"부서\">IT금융개발부</Col><Col id=\"당월\">3</Col><Col id=\"전월\">1</Col></Row><Row><Col id=\"부서\">IT글로벌개발팀</Col><Col id=\"당월\">3</Col><Col id=\"전월\">2</Col></Row></Rows>");
            this._addDataset(obj.name, obj);
            
            // global variable

            
            obj = null;
        };
        
        // property, event, createMainFrame
        this.on_initApplication = function()
        {
            // properties
            this.set_id("Application_Desktop");
            this.set_screenid("Desktop_screen");

            if (this._is_attach_childframe)
            	return;
            
            // frame
            var mainframe = this.createMainFrame("mainframe","0","0","1280","720",null,null,this);
            mainframe.set_showtitlebar("true");
            mainframe.set_showstatusbar("true");
            mainframe.set_titletext("TopLeftFrame");
            mainframe.on_createBodyFrame = this.mainframe_createBodyFrame;
            // tray

        };
        
        this.loadPreloadList = function()
        {

        };
        
        this.mainframe_createBodyFrame = function()
        {
            var obj = new ChildFrame("QuickViewFrame", null, null, null, null, null, null, "", this);
            
            obj.set_showtitlebar("false");
            obj.set_showstatusbar("false");
            obj.set_border("0px none");
			
            this.addChild(obj.name, obj);
            obj.set_formurl(nexacro._quickview_formurl);
            this.frame = obj;
            
            obj = null;
        };
        
        this.on_initEvent = function()
        {
        };
		// script Compiler
        this.registerScript("Application_Desktop.xadl", function() {
        this.av_Form_Work = "";

        this.Application_onload = function(obj,e)
        {
        	this.fn_init(obj);
        };


        this.fn_init = function (obj)
        {
        	this.MENU.filter("MENU_FLAG == '1'");
        	this.av_Form_Work = this.mainframe.VFrameSet00.HFrameSet00.WorkFrameSet;
        };
        });
		this.checkLicense("");
        
        this.loadPreloadList();
        this.loadCss("xcssrc::Chart.xcss");
        this.loadCss("xcssrc::CalendarStyle.xcss");
        this.loadIncludeScript("Application_Desktop.xadl");
    };
}
)();
