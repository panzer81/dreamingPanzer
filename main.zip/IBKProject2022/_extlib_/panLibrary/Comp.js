/**
*  @MenuPath    lfLibrary
*  @FileName 	Comp.js
*  @Creator 	comchief
*  @CreateDate 	2018.10.12
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2018.10.12     	comchief 	            	최초 생성 
*******************************************************************************
*/

var pForm  = nexacro.Form.prototype;

/**
 * @class 폼 로드시에 대상 Edit 컴포넌트 IE의 -ms-clear 동일한 기능으로 동작
 * @param {Edit}           대상 Edit 컴포넌트
 * @return N/A
 */
pForm._gfnSetEditMsClear = function (oEdt)
{	
	if (!oEdt._ms_clear) 
	{	
		return;	
	}
	var _oParent = oEdt.parent;
	
	// "Edit 컴포넌트명 + _X"
	var sClrBtnNm = oEdt.name + "_" + "X";
	
	// 현재 Edit 컴포넌트를 기준으로 Button의 위치를 셋팅한다.
	var nWidth = parseInt(oEdt.getOffsetWidth()	);
	var nHeight= parseInt(oEdt.getOffsetHeight());
	var nTop   = parseInt(oEdt.getOffsetTop()	);
	var nLeft  = parseInt(oEdt.getOffsetLeft()	);
	
	// 생성될 Button의 Width, Height 값
	var nBtnWidth = nHeight-3;
	var nBtnHeight= nHeight;
	
	// 현재 Edit 컴포넌트가 있는 위치에 Button을 생성한다.
	// Edit와 Button은 1:1 관계이다.	
	var oBtn = new Button();  
		oBtn.init(sClrBtnNm, nLeft+(nWidth-nBtnWidth), nTop, nBtnWidth, nBtnHeight, null, null);
	
	// Button은 항상 Edit와 함께 움직이도록 한다.
	oBtn.set_left(oEdt.name + ":" + (nBtnWidth*-1));
	
	// Button의 Default 값은 false
	oBtn.set_visible(false);
	
	// Style cssclass로 셋팅한다. (Ex. oBtn.set_cssclass('btnMsClear');)
	oBtn.set_icon("URL('theme://btn_del.png')");
	oBtn.set_iconPosition("left");
	oBtn.set_background("transparent");
	oBtn.set_border("0px none");
	 
	// taborder 사용하지 않는다.
	oBtn.set_tabstop(false);
	
	_oParent.addChild(sClrBtnNm, oBtn); 
	oBtn.show();
	
	// Button Event 제어
	oBtn.addEventHandler("onclick"  	, function (obj, e) {
	
											oEdt.set_value(null);
 											oEdt.setCaretPos(0);										
											oEdt.setFocus();	
											
 											oBtn.set_visible(false);

									      }, this);
	
	oBtn.addEventHandler("onsetfocus"	, function (obj, e) {
											
											oEdt.setFocus();
											
										  }, this);  
	
	// Edit Event 제어								   
	// Edit 컴포넌트 클릭 시 입력된 내용이 존재시에 X 아이콘이 나타난다.
	oEdt.addEventHandler("oneditclick"	, function (obj, e) {
	
											  if (!this.gfnIsNull(oEdt.value)) 
												   oBtn.set_visible(true );
											else 							   
												   oBtn.set_visible(false);

										  }, this);	
	// Edit Event 제어								   
	// Edit 컴포넌트에서 포커스가 나가면 X 아이콘은 없어진다.
	oEdt.addEventHandler("onsetfocus"	, function (obj, e) {
											
											if (!this.gfnIsNull(oEdt.value)) 
												oBtn.set_visible(true );
											
										  }, this);   									  
										  
	// Edit Event 제어								   
	// Edit 컴포넌트에서 포커스가 나가면 X 아이콘은 없어진다.
	oEdt.addEventHandler("onkillfocus"	, function (obj, e) {
	
											if (_oParent.getFocus().name!=oBtn.name) 
												oBtn.set_visible(false );
											
										  }, this);   
										   
	// Edit 컴포넌트 입력 시 입력된 내용이 존재시에 X 아이콘이 나타난다.
	oEdt.addEventHandler("oninput"		, function (obj, e) {
	
											  if (!this.gfnIsNull(oEdt.value)) 
												   oBtn.set_visible(true );	
											else 							   
												   oBtn.set_visible(false);

										  }, this);
	
};

/**
 * @class 폼 로드시에 대상 Edit 컴포넌트의 -ms-clear(X) 버튼 제거
 * @param {Edit}           대상 Edit 컴포넌트
 * @return N/A
 */
pForm._gfnSetEditMsClearRemove = function (oEdt)
{
	var _oParent = oEdt.parent;
	
	// "Edit 컴포넌트명 + _X"
	var sClrBtnNm = oEdt.name + "_" + "X";
	var oBtn	  = _oParent.lookup(sClrBtnNm);
 
	// Remove Object form Parent Form  
	_oParent.removeChild(sClrBtnNm); 
 
	// Destroy Object  
	oBtn.destroy(); 
	oBtn = null;
};

/**
 * @class 폼 로드시에 대상 Edit 컴포넌트 IE의 -ms-clear(X) 동일한 기능으로 동작
 * @param {Edit	  } 대상 Edit 컴포넌트
 * @param {Boolean} 설정값 셋팅
 * @return N/A
 */
pForm.gfnSetEditMsClear = function (oEdt, bMsClear)
{	
	if (this.gfnIsNull(oEdt._ms_clear) || !oEdt._ms_clear) 
	{
		oEdt._ms_clear = true;
	}
	
	if (!this.gfnIsNull(bMsClear)) 
	{
		oEdt._ms_clear = bMsClear;	
	}
	
	if (oEdt._ms_clear)
	{
		pForm._gfnSetEditMsClear(oEdt);	
	}
	else
	{
		pForm._gfnSetEditMsClearRemove(oEdt); // 해당 컴포넌트 X버튼 삭제	
	}
};

/**
 * @class 폼 로드시에 전체 Edit 컴포넌트 IE의 -ms-clear(X) 동일한 기능으로 동작
 * @param {Form   } 현재 폼 Form
 * @param {Boolean} 설정값 셋팅
 * @return N/A
 */
pForm.gfnSetEditMsClearAll = function (oForm, bMsClear)
{		
	var arrComp = oForm.components;
	var nLength = arrComp.length;

	for (var i=0; i<nLength; i++)
	{
		if (arrComp[i] instanceof nexacro.Div) 
		{
			this.gfnSetEditMsClearAll(arrComp[i].form, bMsClear); //재귀함수
		}
		else if (arrComp[i] instanceof nexacro.Tab) 
		{
			this.gfnSetEditMsClearAll(arrComp[i].form, bMsClear); //재귀함수
		}
		else 
		{
			if (arrComp[i] instanceof nexacro.Edit) 
			{
				var oEdt = arrComp[i];
			
				if (this.gfnIsNull(oEdt._ms_clear) || !oEdt._ms_clear) 
				{
					oEdt._ms_clear = true;
				}
					
				if (!this.gfnIsNull(bMsClear)) 
				{
					oEdt._ms_clear = bMsClear;	
				}
			
				if (oEdt._ms_clear) 
				{
					pForm._gfnSetEditMsClear(oEdt);	
				}
				else 
				{
					pForm._gfnSetEditMsClearRemove(oEdt);	// 해당 컴포넌트 X버튼 삭제
				}
			}
		}
	}	 
};

/**
 * @class 월력용 Calendar에 월력 Popup Div을 자동생성하고 해당 Popup Div을 호출
 * @param {Object} obj - 월력용 Calendar
 * @return N/A
 */
pForm.gfnCalMMOndropdown = function (obj)
{
	var pdvName = this.gfnGetCompId(obj);
	
	// Creating pdv
	if (this.gfnIsNull(this.components[pdvName])) 
	{		
		var objCalPopupDiv = new PopupDiv();
		objCalPopupDiv.init(pdvName, obj.getOffsetLeft(), obj.getOffsetBottom(), 180, 200, null, null);		
		this.addChild(pdvName, objCalPopupDiv);
		objCalPopupDiv.show();
		objCalPopupDiv.set_url("Common::cmmCalMMPdv.xfdl");
		objCalPopupDiv.calObj = obj;
	}
	else 
	{
		var objCalPopupDiv = this.components[pdvName];
		
		// Calendar에서 수정한 년도를 Popup Div에 반영
		var sDate = obj.value;
		objCalPopupDiv.form.staYYYY.set_text(sDate.substr(0,4));
	}
	//trace("pdvName : " + pdvName);

	var nLeft = 0; 	
	// Compoent가 오른쪽에 있을 경우 Component와 우측 정렬하여 팝업Div 표시
	if (this.getOffsetWidth() < (obj.getOffsetRight() + 180) ) 
	{
		nLeft = obj.getOffsetWidth() - 180;
	}
	else 
	{
		nLeft = 0; 
	}
	
	var nTop = 0;	
	// Compoent가 아래쪽에 있을 경우 Component 위로 팝업Div 표시
	if (this.getOffsetHeight() < (obj.getOffsetBottom() + 200)) 
	{
		nTop = -200;
	}
	else 
	{
		nTop = obj.getOffsetHeight(); 
	}
	objCalPopupDiv.trackPopupByComponent(obj, nLeft, nTop);
	
	return false;
};

/**
 * @class 해당 콤포넌트의 form으로 부터의 경로를 구하는 함수
 * @param {Object} obj - 콤포넌트
 * @return {String} 해당 콤포넌트의 form으로 부터의 경로
 */
pForm.gfnGetCompId = function (obj)
{
	var sCompId = obj.name;
	var objParent = obj.parent;
	
	while (true)
	{
		//trace("" + objParent + " / " + objParent.name);
		if (objParent instanceof nexacro.ChildFrame)
		{
			break;
		}
		else 
		{
			sCompId = objParent.name + "." + sCompId;
		}
		objParent = objParent.parent;		
	}
	return sCompId;
}
