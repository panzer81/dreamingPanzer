/**
*  @MenuPath    lfLibrary
*  @FileName 	Message.js
*  @Creator 	comchief
*  @CreateDate 	2018.10.12
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2018.10.12     	comchief 	            	최초 생성 
*******************************************************************************
*/

var pForm  = nexacro.Form.prototype;

/**
 * @class 메세지팝업오픈
 * @param {String} sMsgId - 메세지	
 * @param {String} sType - 팝업 Type (A : Alert, C : Confirm)
 * @param {String} sCallback - Callback function
 * @param {String} sMsgId - Popup ID
 * @param {String} sTextAlign - Text Align (left, center ,right)
 * @return {boolean} 
 * @example
 * this.gfnAlert("Message", "A");	
 * this.gfnAlert("Message", "C", "fnMsgCallback", "myMessage");	
 */
pForm.gfnMessage = function(sMsg, sType, sCallback, sMsgId ,sTextAlign)
{
    var objApp = nexacro.getApplication();
	
	if (this.gfnIsNull(sMsg))
	{
		return false;
	}  
	if (this.gfnIsNull(sTextAlign))
	{
		sTextAlign = "center";
	} 	
	
	// 줄바꿈 변경
	sMsg = sMsg.replace(/\\n/g, String.fromCharCode(10));

	var sMsgUrl ="";
	var oArg = {paramContents:sMsg, textAlign:sTextAlign};
	var oOption = {titlebar:"false",dragmovetype:"none"};	
	
	switch(sType) {
		case "A":
			sMsgUrl = "Common::cmmAlert.xfdl";
			break;
		case "C":
			sMsgUrl = "Common::cmmConfirm.xfdl";

			break;
	}
	
	// messagePopup
	if (nexacro.getEnvironmentVariable("evMessagePopup") == "true") 
	{
		if (this.gfnIsNull(sMsgId))
		{
			var nRandom = Math.round(Math.random()*10000);
			var rtn = this.gfnOpenPopup("message" + nRandom, sMsgUrl, oArg, sCallback, oOption);
		}
		else
		{
			var rtn = this.gfnOpenPopup(sMsgId, sMsgUrl, oArg, sCallback, oOption);
		}
		return rtn;
	}
	// alert-cofirm
	else 
	{
		if (sMsgType == "A") 
		{
			alert(sMsg);
		}
		else 
		{
			confirm(sMsg);
		}
	}
};


/**
 * @class 메세지 치환 후 완성된 메시지 리턴
 * @param {String} sMsgId - 메세지ID	
 * @param {Array}  arrArg - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
 * @return {String}
 */
pForm.gfnGetMessage = function(sMsgId, arrArg) 
{
    var objApp = nexacro.getApplication();
	var nRow = objApp.gdsMessage.findRow("MSGID", sMsgId);
	if (nRow < 0) 
	{
		return false;
	}

	var sColumn  = "MSGTEXT";
	var sMsg = objApp.gdsMessage.getColumn(nRow, sColumn);

	// 줄바꿈 변경
	sMsg = sMsg.replace(/\\n/g, String.fromCharCode(10));
	sMsg =  pForm.gfnConvertMessage(sMsg, arrArg);
	
	return sMsg;
};

/**
 * @class 메세지팝업오픈
 * @param {String} sMsgId - 메세지ID	
 * @param {Array} arrArg - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
 * @param {String} [sPopId] - 팝업ID(하나의 callback함수에서 중복된 메시지 처리를 할 경우 PopId구분을 위해 unique한 ID 반드시 사용)
 * @param {String} [sCallback] - 팝업콜백 (confirm성 메시지를 사용시 반드시 필요)
 * @return N/A
 * @example
 * this.gfnAlert(this, "A", "확인하세요");	
 */
pForm.gfnAlert = function (sMsgId, arrArg, sPopId, sCallback)
{
    var objApp = nexacro.getApplication();
	
	if (objApp.gdsMessage.findRow("MSGID", sMsgId) < 0)
	{
		return false;
	}

	var sMsg = objApp.gdsMessage.lookup("MSGID", sMsgId, "MSGTEXT");

	if (this.gfnIsNull(sMsg))
	{
		sMsg = "확인";
	}
	
	// 줄바꿈 변경
	sMsg = sMsg.replace(/\\n/g, String.fromCharCode(10));
	sMsg =  pForm.gfnConvertMessage(sMsg, arrArg);
	
	var sMsgType = objApp.gdsMessage.lookup("MSGID", sMsgId, "MSGTYPE");	
	if (this.gfnIsNull(sPopId)) 
	{
		sPopId = sMsgId;
	}
	
	var sMsgUrl ="";
	switch(sMsgType) {
		case "A":
			sMsgUrl = "Common::cmmAlert.xfdl";
			break;
		case "C":
			sMsgUrl = "Common::cmmConfirm.xfdl";
			if (this.gfnIsNull(sCallback)) 
			{
				trace("callback함수를 지정하지 않았습니다");
			}
			break;
	}
	
	var oArg = {paramContents:sMsg};
	var oOption = {titlebar:"false",dragmovetype:"none"};	
	
	// messagePopup
	if (nexacro.getEnvironmentVariable("evMessagePopup") == "true") 
	{
		this.gfnOpenPopup(sPopId,sMsgUrl,oArg,sCallback,oOption);
	}
	// alert-cofirm
	else 
	{
		if (sMsgType == "A") 
		{
			alert(sMsg);
		}
		else 
		{
			confirm(sMsg);
		}
	}
};

/**
 * @class 메세지 치환
 * @param {String} msg - 메세지	
 * @param {Array} values - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
 * @return {String}
 */
pForm.gfnConvertMessage = function(msg, values) 
{
    return msg.replace(/\{(\d+)\}/g, function() {
        return values[arguments[1]];
    });
};
