/**
*  @MenuPath    lfLibrary
*  @FileName 	Message.js
*  @Creator 	comchief
*  @CreateDate 	2018.10.12
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2018.10.12     	comchief 	            	최초 생성 
*******************************************************************************
*/

var pForm  = nexacro.Form.prototype;

// 상품상세 팝업

/**
 * @class 상품코드 선택시 상품상세 팝업 노출
 * 
 * @param {String} sProdCd - 상품코드. 필수
 * @param {String} sProdLgfYn - 자사/입점 여부. 옵션
 * @papam {String} sSetYns - 세트상품 여부. 옵션
 * @papam {String} sPopupSubId - 팝업id. 옵션
 * @papam {String} bIsReadOnly - readyonly 여부 true일 경우 수정안됨. 옵션  
 * @return
 */
pForm.gfnProductDetailPopup = function (sProdCd ,sProdLgfYn, sSetYns, sPopupSubId, bIsReadOnly) {

   var strTitle = "자사상품 상세";
   var strPath = "frmProdDetail";
   var width = "1110";
   if (typeof(sProdLgfYn) == 'undefined') sProdLgfYn = "Y";
   if (typeof(sSetYns) == 'undefined') sSetYns = "N";
   if (typeof(sPopupSubId) == 'undefined') sPopupSubId = "_1";
   if (typeof(bIsReadOnly) == 'undefined') bIsReadOnly = false;

   if(sProdLgfYn == "N"){
	   strTitle = "입점상품 상세";	
	   strPath = "frmProdDetailList";
	   width = "1230";
   }else if(sProdLgfYn == "Y"){
	   if(sSetYns == "Y"){
		   strTitle = "세트상품 상세";
		   strPath = "frmSetProdDetail";
	   }else{
		   strTitle = "자사상품 상세"; 
		   strPath = "frmProdDetail";
	   }	   	
   }   
   var sTitle = this.gfnGetWord(strTitle); // 모달팝업
   var sPopupId = strPath+sProdCd+sPopupSubId;
   var oArg = { prodcd:sProdCd ,isReadOnly:bIsReadOnly};
   var sPopupCallBack = "";
   var oOption = { popuptype:"modeless", 
   title:sTitle,width:width,height:"850" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
   this.gfnOpenPopup(sPopupId, "Popup::"+strPath+".xfdl", oArg, sPopupCallBack, oOption);
}; 

// 주문상세 팝업
pForm.gfnOrderDetailPopup = function (sOrdNo) {
   trace("sOrdNo: " + sOrdNo);
   var sTitle = this.gfnGetWord("주문정보상세"); // 모달팝업
   var oArg = { ordNo:sOrdNo };
   var sPopupCallBack = "";
   var oOption = { popuptype:"modeless", title:sTitle,width:"1090",height:"850" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
   this.gfnOpenPopup("OrderDetailPopup_"+sOrdNo, "Popup::frmOrderDetail.xfdl", oArg, sPopupCallBack, oOption);
};

// 회원정보 팝업
try {
	btoa;
} catch(e) {
	btoa = function(val) { return val; };
}

pForm.gfnMemberInfoPopup = function (sMemId, type) {
	trace("sMemId: " + sMemId);
	var sTitle = this.gfnGetWord("회원정보");
	var oArg = { memId:sMemId, type:type };
	var sPopupCallBack = "";
	var oOption = { popuptype:"modeless", title:sTitle,width:"1090",height:"719" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	this.gfnOpenPopup("MemberInfoPopup_"+btoa(encodeURIComponent(sMemId)), "Popup::frmMemberInfo.xfdl", oArg, sPopupCallBack, oOption);
};

// 상담상세 팝업
pForm.gfnCounselDetailPopup = function (sCounselSq) {
	trace("sCounselSq: " + sCounselSq);
	var sTitle = this.gfnGetWord("상담상세");
	var oArg = { counsel_sq:sCounselSq };
	var sPopupCallBack = "";
	var oOption = { popuptype:"modeless", title:sTitle,width:"860",height:"580" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	this.gfnOpenPopup("CounselDetailPopup", "Popup::frmCounselDetail.xfdl", oArg, sPopupCallBack, oOption);
};

// 쿠폰관리 팝업
pForm.gfnCouponPopup = function (couponId, couponNm) {
	trace("couponId: " + couponId + " , couponNm: " + couponNm);
	var sTitle, sUrl;
	if (this.gfnIsNull(couponId))
	{
		sTitle = this.gfnGetWord("쿠폰발급");
		sUrl = "Popup::frmCouponRegist.xfdl";
	}
	else
	{
		sTitle = this.gfnGetWord("쿠폰관리");
		sUrl = "Popup::frmCouponUpdate.xfdl";
	}
	var oArg = {
		couponId:couponId,
		couponNm:couponNm
	};
	var sPopupCallBack = "";
	var oOption = { popuptype:"modeless", title:sTitle,width:"1100",height:"600" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	this.gfnOpenPopup("CouponPopup", sUrl, oArg, sPopupCallBack, oOption);
};

// e기프트발급 팝업
pForm.gfnEGiftPopup = function () {
	var sTitle = this.gfnGetWord("신규등록");
	var oArg = {};
	var sPopupCallBack = "";
	var oOption = { popuptype:"modeless", title:sTitle,width:"1050",height:"480" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	this.gfnOpenPopup("SetEGiftPopup", "Popup::frmSetEGift.xfdl", oArg, sPopupCallBack, oOption);
};

// LMS 발송
pForm.gfnSendLmsPopup = function (memId, memNm, mobile1, mobile2, mobile3, contactType) {
	var sTitle = this.gfnGetWord("LMS 발송");
	var oArg;
	if (arguments.length == 1)
	{
		oArg = memId;
	}
	else
	{
		oArg = {
			memId: memId,
			memNm: memNm,
			mobile1: mobile1,
			mobile2: mobile2,
			mobile3: mobile3,
			contactType: contactType
		};
	}
	var sPopupCallBack = "";
	var oOption = { title:sTitle }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	this.gfnOpenPopup("OrderLMSPopup", "Popup::frmOrderLMS.xfdl", oArg, sPopupCallBack, oOption);
};

// 메일 발송
pForm.gfnSendEmailPopup = function (memId, memNm, email, contactType) {
	var sTitle = this.gfnGetWord("메일 발송");
	var oArg;
	if (arguments.length == 1)
	{
		oArg = memId;
	}
	else
	{
		oArg = {
			memId: memId,
			memNm: memNm,
			email: email,
			contactType: contactType
		};
	}
	var sPopupCallBack = "";
	var oOption = { title:sTitle }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	this.gfnOpenPopup("OrderMailSendPopup", "Popup::frmOrderMailSend.xfdl", oArg, sPopupCallBack, oOption);
};

// 상품평상세 팝업
pForm.gfnProductCommentDetailPopup = function (reviewSq, refresh) {
	var sTitle = this.gfnGetWord("상품평상세");
	refresh = refresh instanceof Function ? refresh.bind(this) : null;
	var oArg = {
		reviewSq: reviewSq,
		refresh: refresh
	};
	var sPopupCallBack = "";
	var oOption = { popuptype:"modeless", title:sTitle,width:"1090",height:"490" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	this.gfnOpenPopup("MemberCmtDetailPopup_"+reviewSq, "Popup::frmMemberCmtDetail.xfdl", oArg, sPopupCallBack, oOption);
};

// 우편번호 찾기
pForm.gfnPostcodePopup = function (sPostcodeCallback) {
	var sTitle = this.gfnGetWord("우편번호 찾기");
	var oArg = { callback: this.lookupFunc(sPostcodeCallback) };
	var sPopupCallBack = "";
	var oOption = { popuptype:"modeless", title:sTitle,width:"480",height:"590" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	this.gfnOpenPopup("PostcodePopup", "Popup::frmPostcode.xfdl", oArg, sPopupCallBack, oOption);
};

// 윈도우 팝업
// this.gfnWindowOpenPopup("http://www.lfmall.co.kr", "1000", "800", "yes");
pForm.gfnWindowOpenPopup = function (url, popupWidth, popupHeight, scrolBars) {

	var sw = screen.availWidth;			// 화면 넓이
	var sh = screen.availHeight;		// 화면 높이
	var potionw = (sw-popupWidth)/2;	// 가로 위치
	var posionh = (sh-popupHeight)/2;	// 세로 위치

	if(!this.gfnIsNull(url)){
		window.open(url, "_blank", "width="+popupWidth+",height="+popupHeight+",top="+posionh+",left="+potionw+",resizable=no,scrollbars="+scrolBars);
	}
};

// 입점업체 팝업
pForm.gfnSupplyEntrPopup = function(sSupplyEntrNm) {
	var sTitle = this.gfnGetWord("입점업체");
	var oArg = { SUPPLY_ENTR_NM:sSupplyEntrNm };
	var oOption = {title:sTitle,width:"805",height:"660"};	//top, left를 지정하지 않으면 가운데정렬
	this.gfnOpenPopup("SupplyEntrPopup", "Popup::frmSupplyEntr.xfdl", oArg, "fnPopupCallback", oOption);
};

// 상품스크린샷캡쳐 팝업
pForm.gfnProdScreenshotCapturePopup = function(sProdCd, sPortalGb) {
	var sTitle = this.gfnGetWord("상품스크린샷캡쳐");
	var oArg = { PROD_CD:sProdCd, PORTAL_GB:sPortalGb };
	var oOption = { title:sTitle,width:"1090",height:"660" };	//top, left를 지정하지 않으면 가운데정렬
	this.gfnOpenPopup("ProdScreenshotCapturePopup", "Popup::frmProdScreenshotCapture.xfdl", oArg, "", oOption);
};

// 상품스크린샷캡쳐이력 팝업
pForm.gfnProdScreenshotCaptureHistoryPopup = function(sProdCd) {
	var sTitle = this.gfnGetWord("상품스크린샷캡쳐이력");
	var oArg = { PROD_CD:sProdCd };
	var oOption = { title:sTitle,width:"585",height:"405" };	//top, left를 지정하지 않으면 가운데정렬
	this.gfnOpenPopup("ProdScreenshotCaptureHistoryPopup", "Popup::frmProdScreenshotCaptureHistory.xfdl", oArg, "", oOption);
};

// 즉시할인쿠폰발급 팝업
pForm.gfnJustNowDcCouponIssuePopup = function(oArg) {
	var sTitle = this.gfnGetWord("즉시할인쿠폰발급");
	var oOption = { title:sTitle,width:"655",height:"480" };	//top, left를 지정하지 않으면 가운데정렬
	this.gfnOpenPopup("JustNowDcCouponIssuePopup", "Popup::frmJustNowDcCouponIssue.xfdl", oArg, "", oOption);
};

// 계정관리자 또는 신청자 팝업
pForm.gfnAccountManagerPopup = function(sTitle, oArg, sPopupId) {
	var oOption = {title:sTitle,width:"480",height:"588"};	//top, left를 지정하지 않으면 가운데정렬
	this.gfnOpenPopup(sPopupId, "Popup::frmAccountManager.xfdl", oArg, "fnPopupCallback", oOption);
};

// 등록자 팝업
pForm.gfnCreateMemberPopup = function(sTitle, oArg, sPopupId) {
	var oOption = {title:sTitle,width:"480",height:"440"};	//top, left를 지정하지 않으면 가운데정렬
	this.gfnOpenPopup(sPopupId, "Popup::frmCreateManager.xfdl", oArg, "fnPopupCallback", oOption);
};

// 수정자 팝업
pForm.gfnModifyMemberPopup = function(sTitle, oArg, sPopupId) {
	var oOption = {title:sTitle,width:"480",height:"440"};	//top, left를 지정하지 않으면 가운데정렬
	this.gfnOpenPopup(sPopupId, "Popup::frmModifyManager.xfdl", oArg, "fnPopupCallback", oOption);
};

/**
 * 상품추가 팝업
 * @param sPopupId - 팝업콜백ID
 * @param oArg - 파라미터 오브젝트
 * @example
 *     var oArg = {stockLinkYn:vStockLinkYn, supplyEntrCd:vSupplyEntrCd, itemBrandCd:vItemBrandCd, formalGb:vFormalGb, itemCdArray:vItemCdArray, gb:vGb, callparentid:"SetProdCodiItem" };
 *     this.gfnProductAdditionPopup(oArg, "frmProdAdd2");
 */
pForm.gfnProductAdditionPopup = function(sPopupId, oArg) {
	var sTitle = this.gfnGetWord("상품추가");	// 모달팝업
	var oOption = {title:sTitle,width:"1110",height:"850",resizable:true};	//top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	this.gfnOpenPopup(sPopupId, "Popup::frmProdAdd.xfdl", oArg, "fnPopupCallback", oOption);
};

// 반품 요청 팝업
pForm.gfnOrderReturnPopup = function (sOrdNo) {
   trace("sOrdNo: " + sOrdNo);
   var sTitle = this.gfnGetWord("반품요청"); // 모달팝업
   var oArg = { ordNo:sOrdNo };
   var sPopupCallBack = "";
   var oOption = { title:sTitle,width:"830",height:"800" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
   this.gfnOpenPopup("OrderReturnPopup", "Popup::frmOrderReturnPopup.xfdl", oArg, sPopupCallBack, oOption);
};

// 교환 요청 팝업
pForm.gfnOrderExchangePopup = function (sOrdNo) {
   trace("sOrdNo: " + sOrdNo);
   var sTitle = this.gfnGetWord("교환요청"); // 모달팝업
   var oArg = { ordNo:sOrdNo };
   var sPopupCallBack = "";
   var oOption = { title:sTitle,width:"830",height:"800" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
   this.gfnOpenPopup("OrderExchangePopup", "Popup::frmOrderExchangePopup.xfdl", oArg, sPopupCallBack, oOption);
};

// 취소 요청 팝업
pForm.gfnOrderCancelPopup = function (sOrdNo) {
   trace("sOrdNo: " + sOrdNo);
   var sTitle = this.gfnGetWord("취소요청"); // 모달팝업
   var oArg = { ordNo:sOrdNo };
   var sPopupCallBack = "";
   var oOption = { title:sTitle,width:"830",height:"800" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
   this.gfnOpenPopup("OrderExchangePopup", "Popup::frmOrderCancelPopup.xfdl", oArg, sPopupCallBack, oOption);
};

// CS전용 메모 팝업
pForm.gfnOrderCSMemoPopup = function (supplyEntrCd) {
   trace("supplyEntrCd: " + supplyEntrCd);
   var sTitle = this.gfnGetWord("CS전용 메모"); // 모달팝업
   var oArg = { supplyEntrCd:supplyEntrCd };
   var sPopupCallBack = "";
   var oOption = { title:sTitle,width:"1090",height:"660" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
   this.gfnOpenPopup("OrderCSMemoPopup", "Popup::frmOrderCSMemo.xfdl", oArg, sPopupCallBack, oOption);
};

// 개런티발행상세
pForm.gfnGuaranteeDetailPopup = function (ordDtlSq) {
   trace("ordDtlSq: " + ordDtlSq);
   var sTitle = this.gfnGetWord("발행정보상세"); // 모달팝업
   var oArg = { ordDtlSq:ordDtlSq };
   var sPopupCallBack = "";
   var oOption = { popuptype:"modeless", title:sTitle,width:"1090",height:"660" }; //top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
   this.gfnOpenPopup("GuaranteeDetailPopup_"+ordDtlSq, "Popup::frmGuaranteeDetail.xfdl", oArg, sPopupCallBack, oOption);
};