/**
*  @MenuPath    lfLibrary
*  @FileName 	Grid.js
*  @Creator 	comchief
*  @CreateDate 	2018.10.16
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2018.10.16     	comchief 	            	최초 생성 
*******************************************************************************
*/

var pForm = nexacro.Form.prototype;
var lvGridNm = new Array();
var lvSeq =0;
//grid propertiy
//pForm.defaultmenulist = "colfix,rowfix,sort,filter,initial";
pForm.defaultmenulist = "sort,cellcopypaste,popup";
pForm.selectmenulist = "checkbox,no,status,replace,find,colhide,export,import,personal,userheader,cellcopypaste";
//pForm.popupmenulist = "colfix,rowfix,filter,initial,replace,find,colhide,export,import,personal,userheader";
//소트
// 헤더 클릭시 정렬 false= 오름/내림 true= 오름/내림/없음
pForm.SORT_TOGGLE_CANCEL = true;
pForm.MARKER_TYPE = "text"; // 정렬 표시자 구분 (text or image)
// Grid Head 에 정렬 상태를 표시할 텍스트 또는 이미지 경로 지정 
pForm.MARKER = ["▲", "▼"];// [오름차순표시, 내림차순표시]
//cell copy and paste 시 chorme용 textarea 저장 object
pForm.tragetGrid = "";
/**
 * @class Grid에 기능 추가
 * @param {Object} obj	- 대상그리드
 * @return N/A
 * @example
 * this.gfnSetGrid(this.grdMain);	
*/
pForm.gfnSetGrid = function(objGrid)
{
	//Grid의 binddataset설정
	var objDs = objGrid.getBindDataset();

	// grid에 바인드된 Dataset이 없는 경우 return;
	if (this.gfnIsNull(objDs)) 
	{
		return;
	}
	// Validation에서 foucus 처리시 사용
	else 
	{
		objDs.bindgrid = objGrid;
	}
	
	//Grid의 UserProperty설정
	var arrProp = this._getGridUserProperty(objGrid);
	if (this.gfnIsNull(arrProp)) 
	{
		return; 		//설정할 속성이 엄쪄용
	}
	
	objGrid.set_enableevent(false);
	objGrid.set_enableredraw(false);	
	objDs.set_enableevent(false); 
	
	var objApp = nexacro.getApplication();
	var objGds = objApp.gdsGridPersonal;
    
	var sFormatId = this._getUniqueId(objGrid);
	var sFormat;
	var nFindRow = objGds.findRow("sFormatId", sFormatId);

	if (nFindRow > -1)
	{
		objGrid.orgformat2 = objGds.getColumn(nFindRow, "sOrgFormat");
		
		sFormat = "<Formats>" + objGds.getColumn(nFindRow, "sFormat") + "</Formats>";
		objGrid.set_formats(sFormat);
	}
	else
	{
		objGrid.orgformat2 = objGrid.getFormatString();
	}
	
	objGrid.arrprop = arrProp;
	this._gfnGridAddProp(objGrid);

	/*********************************************** 이벤트추가 END *************************************************/
	objGrid.set_enableevent(true);
	objGrid.set_enableredraw(true);	
	objDs.set_enableevent(true);
	objGrid.orgformat = objGrid.getCurFormatString();
};	

/**
 * @class  그리드 설정 내부함수<br>
		   그리드에 유저프로퍼티를 Array형태로 반환한다.
 * @param  {Object}objGrid	- 대상그리드
 * @return {Array} user property
 * @example
 * this._getGridUserProperty(this.grdMain);	
 */
pForm._getGridUserProperty = function (objGrid)
{
	var sProp = objGrid.griduserproperty;
	
	var arrdefault = this.defaultmenulist.split(",");
	var arrprop = [];
	
	if (!this.gfnIsNull(sProp))
	{
		arrprop = sProp.split(",");
		for (var i=0; i<arrprop.length; i++)
		{
			if ( arrprop[i].indexOf("!") == 0 )
			{
				//TODO.DEFAULT에서제거
				for ( var j=0; j<arrdefault.length; j++)
				{
					if ( arrdefault[j] == arrprop[i].substr(1))
					{
						arrdefault[j] = "";
					}
				}
				arrprop[i] = "";
			}
		}
	}
	
	var arrmyprop = [];
	for (var i=0; i< arrdefault.length; i++)
	{
		if (!this.gfnIsNull(arrdefault[i]))
		{
			arrmyprop.push(arrdefault[i]);
		}
	}
	
	for (var i=0; i< arrprop.length; i++)
	{
		if (!this.gfnIsNull(arrprop[i]))
		{
			arrmyprop.push(arrprop[i]);
		}
	}

	return arrmyprop;
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화내용 저장을 위해 유니크한 아이디를 구성한다.
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this._gfnGridPersonalize(this.grdMain);	
 */
pForm._getUniqueId = function (objGrid)
{
	var sFormId;
    var sNewWindowFormId;
	var oForm = objGrid.parent; //대상FORM조회
	while (true)
	{
		if (oForm instanceof nexacro.ChildFrame)
		{
			break;
		}
		else
		{
			oForm = oForm.parent;
		}
	}
	sFormId = oForm.name;
    sNewWindowFormId = oForm.form.name;
    if (sFormId === "new_window_" + sNewWindowFormId)
    {
        sFormId = sNewWindowFormId;
    }
    else if (sFormId.indexOf("win") > -1)
	{
		//팝업과 workform구분
		sFormId = oForm.form.divWork.form.name;
	}
    
	var otf = objGrid.parent.parent;
	if (otf instanceof nexacro.Tabpage)
	{
		//탭안에 그리드가 있을경우
		sFormId += "_" + otf.parent.name +"_"+ otf.name;
	}
	else if ( otf instanceof nexacro.Div && otf.name != "divWork")
	{
		//div안에 그리드가 있을경우
		sFormId += "_" + otf.name;
	}
	sFormId += "_" + objGrid.name;
	return sFormId;
};


/**
 * @class Grid에 기능 추가(addCol..)
 * @param {Object} objGrid	- 대상그리드
 * @return N/A
 * @example
 * this._gfnGridAddProp(this.grdMain);	
*/
pForm._gfnGridAddProp = function (objGrid)
{
	var arrProp = objGrid.arrprop;
	var objDs = objGrid.getBindDataset();
	for (var i=0; i<arrProp.length; i++)
	{
		switch(arrProp[i])
		{
			case "checkbox":
				this._gfnGridCheckboxNoStatusAdd(objGrid, objDs, "checkbox");
				break;
			case "no":
				this._gfnGridCheckboxNoStatusAdd(objGrid, objDs, "no");
				break;
			case "status":
				this._gfnGridCheckboxNoStatusAdd(objGrid, objDs, "status");
				break;
			case "find":
				objGrid.addEventHandler("onkeydown", this.gfnGrid_onkeydown, this);
				break;
			case "cellcopypaste":
				objGrid.set_selecttype("multiarea");
				objGrid.addEventHandler("onkeydown", this.gfnGrid_onkeydown, this);
				break;
			case "sort":
				objGrid.addEventHandler("onheadclick", 	 this.gfnGrid_onheadclick, 	 this); 	//헤드클릭이벤트추가
				objGrid.sort = "true";
				break;
			case "popup":
				objGrid.addEventHandler("onrbuttondown", 	 this.gfnGrid_onrbuttondown, 	 this); 	//마우스 우 클릭이벤트
				break;
			default: break;
		}
	}
	
};

/**
 * @class  그리드헤드클릭 이벤트 [Sort, Checkbox]
 * @param {Object} objGrid - 대상그리드
 * @param {Evnet}  e	   - 헤드클릭이벤트
 * @return  N/A
 * @example
 * objGrid.addEventHandler("onheadclick", 	 this.gfnGrid_onheadclick, 	 this);
 */
pForm.gfnGrid_onheadclick = function(objGrid, e)
{
	var sType = objGrid.getCellProperty("head", e.cell, "displaytype");
	if (sType == "checkboxcontrol")
	{
		//head display type이 checkbox일 경우 all/none check기능추가
		try{
			var sProp = objGrid.griduserproperty;
			if(sProp.indexOf("!checkbox") < 0){
				this._gfnHeadCheckSelectAll(objGrid, e);
			}
		}catch(exception){
			this._gfnHeadCheckSelectAll(objGrid, e);
		}
	}
	else
	{
		//sort
		if (this.gfnIsNull(objGrid.sort) || objGrid.sort=="false")
		{
			return;
		}
		else if (objGrid.sort == "true")
		{
			var arr = objGrid.arrprop;

			var bUserHeader = this._gfnGridUserHeaderFlg(objGrid);

			var multiple = false;
			if (e.ctrlkey ) 
			{
				multiple = true;// Ctrl 키
			}
			if (!bUserHeader)
			{
				// 정렬 상태 변경이 성공하면 정렬을 실행한다.
				var rtn = this._gfnGridSetSortStatus(objGrid, e.cell, multiple);
				if (rtn)
				{
					this._gfnGridExecuteSort(objGrid);
				}
			}
			else
			{
				this._gfnGirdUserHeaderExcuteSort(objGrid, e.cell, multiple);
			}
			// 그리드 내용을 맨위로 올림
			objGrid.scrollTo(objGrid.getHScrollPos(), 0);
		}
	}
};

/**
 * @class  마우스우클릭이벤트
 * @param  {Object} objGrid	- 대상그리드
 * @param  {Event}  e		- 우클릭이벤트 
 * @return  N/A
 * @example
 * objGrid.addEventHandler("onrbuttondown", 	 this.gfnGrid_onrbuttondown, 	 this);	
 */
pForm.gfnGrid_onrbuttondown = function (objGrid, e)
{
	var objDs = objGrid.getBindDataset();
	var selectedYn = objDs.getColIndex("SELECTED");
	var grdNm = objGrid.name;
	var cellSum = this.gfnCellSum(objGrid, e);	/* 합계 추가 : 2019-07-22 이상훈 */
	var menu_width = cellSum?135:108;
	
	// popupDiv 있을경우 오픈만...
	if(this.isValidObject("PopupDiv_"+lvSeq)){
		eval("this.PopupDiv_"+lvSeq).destroy(); 
	} 
	lvGridNm[lvSeq] = objGrid;
	trace(objGrid);
	trace(grdNm);
	

	var objPopupDiv = new PopupDiv();
	objPopupDiv.init("PopupDiv_"+lvSeq, e.clientx, e.clienty, menu_width+2, 60, null, null);
	objPopupDiv.set_cssclass("pop_WF_Shadow");
	objPopupDiv.set_background("whitesmoke");
	objPopupDiv.set_border("1px groove black");

	this.addChild("PopupDiv_"+lvSeq, objPopupDiv);
	
	objPopupDiv.targetGrid = objGrid;
	
	var menu_height = 5;
	
	//LFML-63140
	if(!this.gfnIsNull(objGrid.main)) { 
	
		if(objGrid.main == "frmProdMng" || objGrid.main == "frmSaleStyle") {
			
			var gfnPopUpDivColFix_onclick = function(select) {
				return function(objStc) {
					var divObj  = objStc.parent.parent;
					var objGrid = lvGridNm[0];
					
					for(var i = 0; i < objGrid.getFormatColCount(); i++) {
						e.fromobject.setFormatColProperty(i, "band", "body");
					}
					
					console.log(e)
					
					//정렬부분 열고정시 cell 이 다르게 들어옴 하드코딩
					e.fromobject.setFormatColProperty(e.col, "band", "left");
					
					divObj.closePopup();
					divObj.destroy();
				};
			};
			
			objPopupDiv.set_height(objPopupDiv.height+26);
			
			var pMenu_fix_00 = new Static("pMenu_fix_00", 0, menu_height, menu_width, 22, null, null);
			pMenu_fix_00.addEventHandler("onclick", gfnPopUpDivColFix_onclick(true),this); 
			pMenu_fix_00.set_cssclass("sta_WF_MouseOver");
			pMenu_fix_00.set_textAlign("center");
			objPopupDiv.form.addChild("pMenu_fix_00", pMenu_fix_00); 
			pMenu_fix_00.set_text("열 고정");
			pMenu_fix_00.show();
			
			menu_height += 26;
		}
	}


	var handler = function(select) {
		return function(objStc) {
			var divObj  = objStc.parent.parent;
			var objGrid = lvGridNm[0];
			select && this._gfnGridSelectCell(objGrid, e.row, e.cell);
			this._gfnGridCopyEvent(objGrid, e);
			divObj.closePopup();
			divObj.destroy();
		};
	};
	
	var pMenu_Copy_01 = new Static("pMenu_Copy_01", 0, menu_height, menu_width, 22, null, null);
	pMenu_Copy_01.addEventHandler("onclick", handler(true), this); 
	pMenu_Copy_01.set_cssclass("sta_WF_MouseOver");
	pMenu_Copy_01.set_textAlign("center");
	objPopupDiv.form.addChild("pMenu_Copy_01", pMenu_Copy_01); 
	pMenu_Copy_01.set_text("복사");
	pMenu_Copy_01.show();
	
	var pMenu_Copy_02 = new Static("pMenu_Copy_02", 0, pMenu_Copy_01.top+26, menu_width, 22, null, null);
	pMenu_Copy_02.addEventHandler("onclick", handler(), this); 
	pMenu_Copy_02.set_cssclass("sta_WF_MouseOver");
	pMenu_Copy_02.set_textAlign("center");
	objPopupDiv.form.addChild("pMenu_Copy_02", pMenu_Copy_02); 
	pMenu_Copy_02.set_text("선택된 셀 복사");
	pMenu_Copy_02.show();
	
	var lastMenuObj = pMenu_Copy_02;
	
	//엑셀다운로드
	/* 그리드 객체에 hideMenu user property가 등록되어 있고 excel값이 있으면 메뉴 구성 안함 */
	if (objGrid.getBindDataset().rowcount > 0 && (!objGrid.hideMenu || (objGrid.hideMenu && !objGrid.hideMenu.match(/excel/)))) {
		objPopupDiv.set_height(objPopupDiv.height+31);

		var pMenuBar_00 = new Static("pMenuBar_00", 0, pMenu_Copy_02.top+26, menu_width, 1, null, null);
		pMenuBar_00.set_background("#a8a8a8");
		objPopupDiv.form.addChild("pMenuBar_00", pMenuBar_00); 
		pMenuBar_00.show();
		
		var pMenu_Excel_01 = new Static("pMenu_Excel_01", 0, pMenuBar_00.top+5, menu_width, 22, null, null);
		pMenu_Excel_01.addEventHandler("onclick", this.gfnExcelMenu_onclick, this); 
		pMenu_Excel_01.set_cssclass("sta_WF_MouseOver");
		pMenu_Excel_01.set_textAlign("center");
		objPopupDiv.form.addChild("pMenu_Excel_01", pMenu_Excel_01); 
		pMenu_Excel_01.set_text("엑셀 다운로드");
		pMenu_Excel_01.show();
		
		lastMenuObj = pMenu_Excel_01;
	}
	
	//드래그 선택
	if (selectedYn != -1) {
	
		objPopupDiv.set_height(objPopupDiv.height+56);
		
		var pMenuBar_01 = new Static("pMenuBar_01", 0, lastMenuObj.top+26, menu_width, 1, null, null);
		pMenuBar_01.set_background("#a8a8a8");
		objPopupDiv.form.addChild("pMenuBar_01", pMenuBar_01); 
		pMenuBar_01.show();
	
		var pMenu_Drag_01 = new Static("pMenu_Drag_01", 0, pMenuBar_01.top+5, menu_width, 22, null, null);
		pMenu_Drag_01.addEventHandler("onclick", this.gfnPopUpDiv_onclick,this); 
		pMenu_Drag_01.set_cssclass("sta_WF_MouseOver");
		pMenu_Drag_01.set_textAlign("center");
		objPopupDiv.form.addChild("pMenu_Drag_01", pMenu_Drag_01); 
		pMenu_Drag_01.set_text("드래그 영역 선택");
		pMenu_Drag_01.show();

		var pMenu_Drag_02 = new Static("pMenu_Drag_02", 0, pMenu_Drag_01.top+26, menu_width, 22, null, null);
		pMenu_Drag_02.addEventHandler("onclick", this.gfnPopUpDiv_onclick,this); 
		pMenu_Drag_02.set_cssclass("sta_WF_MouseOver");
		pMenu_Drag_02.set_textAlign("center");
		objPopupDiv.form.addChild("pMenu_Drag_02", pMenu_Drag_02); 
		pMenu_Drag_02.set_text("드래그 영역 해제");
		pMenu_Drag_02.show();
		
		lastMenuObj = pMenu_Drag_02;
	}
	
	if (cellSum != null && (!objGrid.hideMenu || (objGrid.hideMenu && !objGrid.hideMenu.match(/sum/)))) {
		objPopupDiv.set_height(objPopupDiv.height+31);
		
		var pMenuBar_02 = new Static("pMenuBar_02", lastMenuObj.left, lastMenuObj.top+26, menu_width, 1, null, null);
		pMenuBar_02.set_background("#a8a8a8");
		objPopupDiv.form.addChild("pMenuBar_02", pMenuBar_02); 
		pMenuBar_02.show();

		var pMenuCellSum = new Static("pMenuCellSum", lastMenuObj.left, pMenuBar_02.top+5, menu_width, 22, null, null);
		pMenuCellSum.set_cssclass("sta_WF_MouseOver");
		pMenuCellSum.set_textAlign("center");
		objPopupDiv.form.addChild("pMenuCellSum", pMenuCellSum); 
		pMenuCellSum.set_text("합계 : " + cellSum);
		pMenuCellSum.show();	
	}
	objPopupDiv.show(); 
	//objPopupDiv.trackPopup(e.clientx,e.clienty);
	objPopupDiv.trackPopupByComponent(objGrid,e.canvasx,e.canvasy);
};

pForm._gfnGridSelectCell = function(obj, row, cell)
{
	obj.clearSelect();
	switch(obj.selecttype) {
	case "row":
	case "multirow":
		obj.selectRow(row);
		break;
	case "cell":
		obj.selectCell(row, cell);
		break;
	case "area":
	case "multiarea":
		obj.selectArea(row, cell, row, cell);
		break;
	}
};

/**
 * @class  팝업DIV Static 클릭이벤트
 * @param  {Object} Static	- Static 버튼
 * @param  {Event}  e		- 클릭이벤트 
 * @return  N/A
 * @example
 * objStatic1.addEventHandler("onclick", this.gfnPopUpDiv_onclick,this); 
 */
pForm.gfnPopUpDiv_onclick = function (objStc, e)
{
	var divObj  = objStc.parent.parent;
	
	switch(objStc.name) {
	case "pMenu_Drag_01":
		var rows = lvGridNm[0].getSelectedRows();
		var objDs = lvGridNm[0].getBindDataset();
		for(var j=0; j<rows.length; j++){
			objDs.setColumn(rows[j],"SELECTED",1);
		}
		divObj.closePopup();
		divObj.destroy();
		break;
	case "pMenu_Drag_02":
		var rows = lvGridNm[0].getSelectedRows();
		var objDs = lvGridNm[0].getBindDataset();
		for(var j=0; j<rows.length; j++){
			objDs.setColumn(rows[j],"SELECTED",0);
		}
		divObj.closePopup();
		divObj.destroy();
		break;
	}
};

/**
 * @class  그리드키다운 이벤트 [cellcopypaste]
 * @param {Object} objGrid - 대상그리드
 * @param {Evnet}  e	   - 키다운이벤트
 * @return  N/A
 * @example
 * objGrid.addEventHandler("onheadclick", 	 this.gfnGrid_onheadclick, 	 this);
 */
pForm.gfnGrid_onkeydown =function(objGrid, e)
{
	var keycode = e.keycode;
	if (e.ctrlkey)
	{
		if (keycode == 67)
		{
			//copy
			this._gfnGridCopyEvent(objGrid, e);
		}
		else if (keycode == 86)
		{
			//paste
			this._gfnGridPasteEvent(objGrid, e);
		}
		else if (e.keycode == 70)
		{
			this._gfnGridCellFind(objGrid);
		}
	}
};

pForm._gfnGridCopyEvent = function (objGrid, e)
{
	var sBrowser = system.navigatorname;
	//copy
	if( sBrowser == "nexacro" || sBrowser == "IE"){
		this._gfnGridCopyEventForRuntime(objGrid, e);
	}else {
		this._gfnGridCopyEventForChrome(objGrid, e);
	}
};

/**
 * @class Grid에 기능 추가(addCol..)
 * @param {Object} objGrid	- 대상그리드
 * @param {Object} objDs	- 대상데이터셋
 * @param {Array} addProp	- 기능
 * @return N/A
 * @example
 * this._gfnGridCheckboxNoStatusAdd(this.grdMain, this.dsList, [checkbox,no,status]);	
*/
pForm._gfnGridCheckboxNoStatusAdd = function (objGrid, objDs, addProp)
{	
	var nHeadColIndex;
	if (this.gfnIsNull(objDs.insertheadcell)) 
	{
		nHeadColIndex = 0;
	}
	else 
	{
		nHeadColIndex = objDs.insertheadcell;	
	}

	var nBodyColIndex;
	if (this.gfnIsNull(objDs.insertbodycell)) 
	{
		nBodyColIndex = 0;
	}
	else 
	{
		nBodyColIndex = objDs.insertbodycell;
	}
	
	var nFormatRowCount = objGrid.getFormatRowCount();
	var nHeadCount=-1;
	var nBodyCount=-1;
	for (var i=0; i<nFormatRowCount; i++)
	{
		if (objGrid.getFormatRowProperty(i, "band") == "head") 
		{
			nHeadCount++;
		}
		if (objGrid.getFormatRowProperty(i, "band") == "body") 
		{
			nBodyCount++;
		}
	}

	var sNo = this.gfnGetWord("cmm.no");		// 순번
	var sStatus = this.gfnGetWord("cmm.status");// 상태

	//체크박스
	if (addProp == "checkbox")
	{
		objDs.set_enableevent(false); 
		var idx=-1;
		for ( var j=0; j<objDs.getColCount(); j++)
		{
			var tmpcol = objDs.getColID(j);
			if (tmpcol == "gridcmmcheck")
			{
				idx = j;
			}
		}
		if (idx < 0) 
		{
			objDs.addColumn("gridcmmcheck", "STRING", 1);
		}		
		
		for (var i=0; i<objGrid.getCellCount("head"); i++)
		{
			//헤드텍스트
			var tmp = objGrid.getCellProperty("head" , i, "text");
			if (tmp == "0")
			{
				// head cell index 에 해당하는 body cell index
				var bodyCellIndex = this._gfnGridGetBodyCellIndex(objGrid, i);
				// body cell index 에 해당하는 바인드 컬럼명
				var columnName = this._gfnGridGetBindColumnNameByIndex(objGrid, bodyCellIndex);
				if (columnName == "gridcmmcheck") 
				{
					//return;
					objGrid.deleteContentsCol("body", i);
				}
			}
		}
		objGrid.insertContentsCol(nBodyColIndex);			
		objGrid.setFormatColProperty(nBodyColIndex, "size", "40");	
		objGrid.setCellProperty("head", nHeadColIndex, "displaytype", "checkboxcontrol");
		objGrid.setCellProperty("head", nHeadColIndex, "edittype", "checkbox");
		objGrid.setCellProperty("head", nHeadColIndex, "text", "1");
		objGrid.setCellProperty("body", nBodyColIndex, "displaytype", "checkboxcontrol");
		objGrid.setCellProperty("body", nBodyColIndex, "edittype", "checkbox");
		objGrid.setCellProperty("body", nBodyColIndex, "text", "bind:gridcmmcheck");
		
		objGrid.mergeContentsCell("head", 0, nBodyColIndex, nHeadCount, nBodyColIndex, nHeadColIndex, false);	
		objGrid.mergeContentsCell("body", 0, nBodyColIndex, nBodyCount, nBodyColIndex, nBodyColIndex, false);		
		
		nHeadColIndex++;
 		nBodyColIndex++;
	}
	//번호
	if (addProp == "no")
	{
		for (var i=0; i<objGrid.getCellCount("head"); i++)
		{
			var tmp = objGrid.getCellProperty("head" , i, "text");
			if (tmp == "NO" || tmp == "순번")
			{
				//return;
				objGrid.deleteContentsCol("body", i);
			}
		}
		objGrid.insertContentsCol(nBodyColIndex);	
		objGrid.setFormatColProperty(nBodyColIndex, "size", "50");	
 		objGrid.setCellProperty("head", nHeadColIndex, "text", sNo);	
		objGrid.setCellProperty("head", nHeadColIndex, "textAlign","center");
		objGrid.setCellProperty("body", nBodyColIndex, "text","expr:currow+1");
		objGrid.setCellProperty("body", nBodyColIndex, "textAlign","center");
		objGrid.mergeContentsCell("head", 0, nBodyColIndex, nHeadCount, nBodyColIndex, nHeadColIndex, false);	
		objGrid.mergeContentsCell("body", 0, nBodyColIndex, nBodyCount, nBodyColIndex, nBodyColIndex, false);			
		
		nHeadColIndex++;
 		nBodyColIndex++;
	}
	//상태
	if (addProp == "status")
	{
		for (var i=0; i<objGrid.getCellCount("head"); i++)
		{
			var tmp = objGrid.getCellProperty("head" , i, "text");
			if (tmp == "상태" || tmp == "Status")
			{
				//return;
				objGrid.deleteContentsCol("body", i);
			}
		}
		
		var sInsert = nexacro.wrapQuote(this.gfnGetWord("insert")); //입력
		var sUpdate = nexacro.wrapQuote(this.gfnGetWord("modify")); //수정
		var sDelete = nexacro.wrapQuote(this.gfnGetWord("delete")); //삭제
		var sExpr = "expr:"
				  + "dataset.getRowType(currow)==2?"+sInsert
				  + ":dataset.getRowType(currow)==4?"+sUpdate
				  + ":dataset.getRowType(currow)==8?"+sDelete
				  + ":''";
		
		var nSize = 50;
		if (nexacro.getEnvironmentVariable("evLanguage") == "EN") 
		{
			nSize = 80;
		}
		
		objGrid.insertContentsCol(nBodyColIndex);	
		objGrid.setFormatColProperty(nBodyColIndex, "size", nSize);	
		objGrid.setCellProperty("head", nHeadColIndex, "text", sStatus);	
		objGrid.setCellProperty("head", nHeadColIndex, "textAlign","center");
		objGrid.setCellProperty("body", nBodyColIndex, "displaytype", "expr:dataset.getRowType(currow) != 1 ? 'text' : ''");
		objGrid.setCellProperty("body", nBodyColIndex, "text", sExpr);		
		objGrid.setCellProperty("body", nBodyColIndex, "textAlign","center");
		objGrid.mergeContentsCell("head", 0, nBodyColIndex, nHeadCount, nBodyColIndex, nHeadColIndex, false);	
		objGrid.mergeContentsCell("body", 0, nBodyColIndex, nBodyCount, nBodyColIndex, nBodyColIndex, false);			
		
		nHeadColIndex++;
 		nBodyColIndex++;
	}	
};

/**
 * @class  gfnCreatePopupMenu 내부함수로 팝업메뉴 클릭 시 발생하는 이벤트
 * @param {Object} objGrid	- 대상그리드
 * @param {Evnet}  e 		- 팝업메뉴클릭이벤트
 * @return N/A
 * @example
 * this.gfnPopupmenu_onmenuclick(this.grdMain, nexacro.MenuClickEventInfo);	
 */
pForm.gfnPopupmenu_onmenuclick = function (objMenu, e)
{
	var selectId   = e.id;
	var grid 	   = objMenu.grid;
	var nCellIndex = objMenu.cellindex;	
	var nRowIndex  = objMenu.rowindex;

	switch(selectId) 
	{
		case "colfix"://틀고정 열
			this.fv_CellIndex = nCellIndex;
			this._gfnGridcellFix(grid, this.fv_CellIndex, nRowIndex);
			break;
		case "colfixfree"://틀고정 열 해제
			this._gfnGridCellFree(grid);
			break;
		case "rowfix"://틀고정 행
			if (nRowIndex<0) 
			{
				return;
			}
			grid.fixedRow = nRowIndex;
			this._gfnGridSetCssclass(grid);
			break;
		case "rowfixfree"://틀고정 행 해제
			grid.fixedRow = -1;
			this._gfnGridSetCssclass(grid);
			break;
		case "filter"://필터
			this._gfnGridFilter(grid);
			break;
		case "filterfree"://필터해제
			this._gfnGridCellFilterFree(grid);
			break;
		case "replace"://찾기/바꾸기
			this._gfnGridCellReplace(grid, nCellIndex, nRowIndex);
			break;
		case "colhide"://컬럼숨기기
			this._gfnGridColHideShow(grid, nRowIndex);
			break;	
		case "export"://엑셀내보내기
			this._gfnGridExcelExport(grid, nRowIndex);
			break;	
		case "import"://엑셀가져오기
			this._gfnGridExcelImport(grid, nRowIndex);
			break;	
		case "personal" : //개인화
			this._gfnGridPersonalize(grid);
			break;
		case "initial"://초기화
			grid.set_formats("<Formats>" + grid.orgformat2 + "</Formats>");
			this._gfnGridAddProp(grid);
			break;
		default: break;
	}
};

/**
 * @class  그리드헤드클릭이벤트 내부함수 (헤드클릭시 체크 ALL/None)
 * @param {Object} objGrid - 대상그리드
 * @param {Evnet}  e	   - 헤드클릭이벤트
 * @return  N/A
 * @example
 * this._gfnHeadCheckSelectAll(objGrid, e); //ALL CHECK
 */
pForm._gfnHeadCheckSelectAll = function (objGrid, e)
{
	trace("_gfnHeadCheckSelectAll");
	if (objGrid.readonly == true) 
	{
		return;
	}
	
	var sType;
	var sChk;
	var sVal;
	var sChkVal;
	var oDsObj;
	var nHeadCell  = e.cell;
	var nBodyCell;
	var nSubCnt = objGrid.getSubCellCount("head", nHeadCell);

	oDsObj  = objGrid.getBindDataset();
	
	if (oDsObj.getRowCount() < 1) 
	{
		return;
	}
	
	if (objGrid.getCellCount("body") != objGrid.getCellCount("head")) 
	{
		nBodyCell = parseInt(objGrid.getCellProperty("head", nHeadCell, "col"));
	} 
	else 
	{
		nBodyCell = e.cell;
	}
	sChkVal = objGrid.getCellProperty("body", nBodyCell, "text");
	sChkVal = sChkVal.toString().replace("bind:", "");
		
	// Merge한 셀이 없는 경우
	sType = objGrid.getCellProperty("head", nHeadCell, "displaytype");

	if (sType != "checkboxcontrol") 
	{
		return;
	}

	// Head셋팅
	sVal = objGrid.getCellProperty("head", nHeadCell, "text");

	if (this.gfnIsNull(sVal))
	{
		sVal = "0";
	}

	if (sVal == "0") 
	{
		objGrid.setCellProperty("head", nHeadCell, "text", "1");
		sChk="1";
	} 
	else 
	{
		objGrid.setCellProperty("head", nHeadCell, "text", "0");
		var bodyCellIndex = this._gfnGridGetBodyCellIndex(objGrid, nHeadCell);
		//body cell index 에 해당하는 바인드 컬럼명
		var columnName = this._gfnGridGetBindColumnNameByIndex(objGrid, bodyCellIndex);
		if (columnName == "gridcmmcheck") 
		{
			 sChk="";
		}
		else
		{
			sChk="0";
		}
	}
	
	// Body셋팅
	oDsObj.set_enableevent(false);
	for (var i=0 ; i< oDsObj.rowcount ; i++) 
	{ 
		var sCellType = objGrid.getCellPropertyValue(i, nHeadCell, "edittype" );
		if(sCellType =="checkbox")
		{
			oDsObj.setColumn(i, sChkVal, sChk);
		}
	}
	oDsObj.set_enableevent(true);
};

/**
 * @class 정렬가능여부리턴
 * @param {Object} grid - 대상그리드
 * @param {Number} headCellIndex - 대상셀INDEX
 * @param {Boolean}multiple - 멀티소트여부 
 * @param {Number} sortStatus - 소트상태  
 * @return{Boolean} sort 가능/불가능 여부
 * @example
 * this._gfnGridSetSortStatus(obj, e.cell, multiple);	
 */
pForm._gfnGridSetSortStatus = function(grid, headCellIndex, isMultiple, sortStatus, bodyCellIndex)
{
	// head cell index 에 해당하는 body cell index
	if (this.gfnIsNull(bodyCellIndex))
	{
		bodyCellIndex = this._gfnGridGetBodyCellIndex(grid, headCellIndex);
	}
	if ( bodyCellIndex < 0 ) 
	{
		return false;
	}
	
	// body cell index 에 해당하는 바인드 컬럼명
	var columnName = this._gfnGridGetBindColumnNameByIndex(grid, bodyCellIndex);
	if (this.gfnIsNull(columnName))
	{
		trace("Check Grid body cell bind value");
		return false;
	}
	
	if (this.gfnIsNull(isMultiple)) 
	{
		isMultiple = false;
	}
	if (this.gfnIsNull(sortStatus)) 
	{
		sortStatus = -1;
	}
	
	// 대상 grid 에 정렬정보를 가지는 사용자 속성 확인/추가
	if (this.gfnIsNull(grid.sortInfos))
	{
		grid.sortInfos = {};
	}
	
	// 정렬대상컬럼 (순서중요)
	if (this.gfnIsNull(grid.sortItems))
	{
		grid.sortItems = [];
	}
	
	var sortInfos = grid.sortInfos,
		sortItems = grid.sortItems,
		sortInfo = sortInfos[columnName],
		sortItem,
		status;
	
	if (this.gfnIsNull(sortInfo))
	{
		var headText = grid.getCellText(-1, headCellIndex);
		
		// executeSort에서 정렬 표시를 위해 cell index 가 필요한데
		// cell moving 될 경우 index는 변하므로 cell object 를 참조하여 값을 얻어온다. 		
		var refCell = this._gfnGridGetGridCellObject(grid, "head", headCellIndex);
		sortInfo = sortInfos[columnName] = {status: 0, text: headText, refCell: refCell};
	}
	// set sort status
	if (isMultiple) 
	{		
		status = sortInfo.status;
		if (sortStatus == -1)
		{
			if (status == 0)
			{
				sortInfo.status = 1;
			} 
			else if(status == 1) 
			{
				sortInfo.status = 2;
			} 
			else if(status == 2) 
			{
				sortInfo.status = (this.SORT_TOGGLE_CANCEL ? 0 : 1);
			}
		}
		else 
		{
			sortInfo.status = sortStatus;
		}
	}
	else 
	{
		for (var p in sortInfos) 
		{
			if(sortInfos.hasOwnProperty(p))
			{
				sortInfo = sortInfos[p];
				if (p == columnName) 
				{
					status = sortInfo.status;
					if (sortStatus == -1) 
					{
						if (status == 0) 
						{
							sortInfo.status = 1;
						} 
						else if(status == 1)
						{
							sortInfo.status = 2;
						} 
						else if(status == 2)
						{
							sortInfo.status = (this.SORT_TOGGLE_CANCEL ? 0 : 1);
						}
					}
					else 
					{
						sortInfo.status = sortStatus;
					}
				}
				else
				{
					sortInfo.status = 0;
				}
				if (sortInfo.status == 0)
				{
					for (var j=0, len2=sortItems.length; j<len2; j++) 
					{
						if (sortItems[j] !== columnName)
						{
							sortItems.splice(j, 1);
							break;
						}
					}
				}
			}
		}
	}
	
	// 컬럼정보 등록
	var hasItem = false;
	for (var i=0, len=sortItems.length; i<len; i++) 
	{
		if (sortItems[i] == columnName) 
		{
			hasItem = true;
			break;
		}
	}	
	if (!hasItem)
	{
		sortItems.push(columnName);
	}
	return true;
}; 

/**
 * @class 소트를 실행한다
 * @param {Object}  grid 대상 Grid Component
 * @return{String}  N/A
 * @example
 * this._gfnGridExecuteSort(obj);	
 */  
pForm._gfnGridExecuteSort = function(grid) 
{
	var sortInfo, 
		sortItem,
		sortInfos = grid.sortInfos,
		sortItems = grid.sortItems,
		columnName,
		status,
		cell,
		sortString = "";
		
	if (this.gfnIsNull(sortInfos) || this.gfnIsNull(sortItems))
	{
		return;
	}

	// keystring 조합
	for (var i=0; i<sortItems.length; i++) 
	{
		columnName = sortItems[i];
		sortInfo = sortInfos[columnName];
		status = sortInfo.status;
		cell = sortInfo.refCell;
		
		// 컬럼삭제 등으로 제거될 수 있으므로 실제 column 이 존재하는지
		// 확인하여 없으면 제거해 준다.
		if (this.gfnIsNull(cell) || grid.getBindCellIndex("body", columnName) < 0)
		{
			// 컬럼정보제거
			sortItems.splice(i, 1);
			sortInfos[columnName] = null;
			delete sortInfos[columnName];
			
			i--;
		}
		else if (status > 0)
		{
			sortString += (status == 1 ? "+" : "-") + columnName;
		}
	}
	
	var ds = grid.getBindDataset();
	// keystring 확인
	var curKeyString = ds.keystring;
	var groupKeyString = "";
	
	if (curKeyString.length > 0 && curKeyString.indexOf(",") < 0)
	{
		var sIndex = curKeyString.indexOf("S:");
		var gIndex = curKeyString.indexOf("G:");

		if (sIndex > -1)
		{
			groupKeyString = "";
		}
		else
		{
			if (gIndex < 0)
			{
				groupKeyString = "G:"+curKeyString;
			}
			else
			{
				groupKeyString = curKeyString;
			}
		}
	}
	else
	{
		var temps = curKeyString.split(",");
		var temp;
		for (var i=0,len=temps.length; i<len; i++)
		{
			temp = temps[i];
			if (temp.length > 0 && temp.indexOf("S:") < 0)
			{
				if (temp.indexOf("G:") < 0)
				{
					groupKeyString = "G:"+temp;
				}
				else
				{
					groupKeyString = temp;
				}
			}
		}
	}
	
//--------------------TOBE--------------------
	if(grid.hscrollbar)
	{	
		var hPos_ = grid.hscrollbar.pos;  
	}
//--------------------------------------------	 

	if (sortString.length > 0)
	{
		var sortKeyString = "S:"+sortString;
		
		if ( groupKeyString.length > 0 )
		{
			ds.set_keystring(sortKeyString + "," + groupKeyString);
		}
		else
		{
			ds.set_keystring(sortKeyString);
		}
		
		grid.sortKeyString = sortKeyString;
	}
	else
	{		
		ds.set_keystring(groupKeyString);
		grid.sortKeyString = "";
	}

	// 정렬표시
	var type = this.MARKER_TYPE;
	var index, marker;
	for (var p in sortInfos) 
	{
		if (sortInfos.hasOwnProperty(p))
		{
			sortInfo = sortInfos[p];			
			cell = sortInfo.refCell;
			if (cell)
			{
				index = cell._cellidx;
				marker = this.gfnDecode(sortInfo.status, 1, this.MARKER[0], 2, this.MARKER[1], "");
				grid.setCellProperty( "head", index, "text", sortInfo.text + marker);
			}
		}
	}
//--------------------TOBE-------------------- 
	 if(grid.hscrollbar && hPos_ > 0){
		grid.hscrollbar.set_pos(hPos_); 
	}
//--------------------------------------------		
};

/**
 * @class 유저헤더를 이용한 정렬
 * @param {Object} grid - 대상그리드
 * @return N/A
 * @example
 * this._gfnGirdUserHeaderExcuteSort(objGrid);
 */
pForm._gfnGirdUserHeaderExcuteSort = function (objGrid, headCellIndex, multiple)
{
	var bindCol = objGrid.getCellProperty("head", headCellIndex, "calendarweekformat");
	if (this.gfnIsNull(bindCol))
	{
		return false; //헤더에 바인드없음
	}

	var bodyCellIdx = 0;
	var nbodyCnt = objGrid.getCellCount("body");
	for (var i=0; i<nbodyCnt; i++)
	{
		var tmp =  objGrid.getCellProperty("body", i, "text");
		if (tmp == bindCol)
		{
			bodyCellIdx = i;
			break;
		}
	}
	var rtn = this._gfnGridSetSortStatus(objGrid, headCellIndex, multiple, "", bodyCellIdx);
	if (rtn)
	{
		this._gfnGridExecuteSort(objGrid);
	}
};

//////////////////////////////////////////////////////////////////////////CELL COPY AND PASTE//////////////////////////////////////////////////////////////////////////
/**
 * @class copy event(nexacro, ie)
 * @param {Object} obj- 대상그리드
 * @param {Event}  e - key down event
 * @return N/A
 * @example
 * this._gfnGridCopyEventForRuntime(obj, e);	
*/
//pForm._gfnGridCopyEventForRuntime = function (obj, e)
//{
//	var startrow = nexacro.toNumber(obj.selectstartrow);
//	if (startrow == -9)
//	{
//		return;
//	}
//
//	var endrow   = nexacro.toNumber(obj.selectendrow);
//	if (endrow == -9)
//	{
//		return;
//	}
//	
//	var startcol = 0;
//	var endcol = 0;
//	
//	if (obj.selecttype == "row" || obj.selecttype == "multirow")
//	{
//		startcol = 0;
//		endcol = obj.getCellCount("body")-1;
//	}
//	else
//	{
//		startcol = nexacro.toNumber(obj.selectstartcol);
//		endcol   = nexacro.toNumber(obj.selectendcol);
//	}
//	var colSeperator = "\t"; 
//	var copyData = "";
//	var checkIndex = {};
//	
//	for (var i = startrow; i <= endrow; i++) 
//	{
//		for (var j = startcol; j <= endcol; j++) 
//		{
//			if (obj.getCellProperty("body", j, "displaytype") != "buttoncontrol")
//			{
//				var value = obj.getCellValue(i,j);
//				if (!this.gfnIsNull(value)) 
//				{
//					if (j < endcol) 
//					{
//						copyData += obj.getCellValue(i,j) + colSeperator;
//					} 
//					else 
//					{
//						copyData += obj.getCellValue(i,j);
//					}
//				}
//			}
//		}
//		if (i < obj.selectendrow)
//		{
//				copyData += "\r\n";
//		}
//	}
//
//	copyData += "\r\n";
//	system.clearClipboard();
//	system.setClipboard("CF_TEXT",copyData);
//
//
//	var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
//};

/**
 * @class copy event(nexacro, ie)
 * @param {Object} obj- 대상그리드
 * @param {Event}  e - key down event
 * @return N/A
 * @example
 * this._gfnGridCopyEventForRuntime(obj, e);	
*/
pForm._gfnGridCopyEventForRuntime = function (obj, e)
{
	var startrow = nexacro.toNumber(obj.selectstartrow);
	if( startrow == -9) return;

	var endrow   = nexacro.toNumber(obj.selectendrow);
	if( endrow == -9) return;
	
	var startcol = 0;
	var endcol = 0;
	
	if( obj.selecttype == "row" || obj.selecttype == "multirow"){
		startcol = 0;
		endcol = obj.getCellCount("body")-1;
	}else{
		startcol = nexacro.toNumber(obj.selectstartcol);
		endcol   = nexacro.toNumber(obj.selectendcol);
	}
	var colSeperator = "\t";
	var copyData = "";
	var checkIndex = {};
	
	for (var i = startrow; i <= endrow; i++) {
		for (var j = startcol; j <= endcol; j++) {
			var value = obj.getCellValue(i,j);
			if(!this.gfnIsNull(value)) {
				if (j < endcol) {
					copyData += obj.getCellValue(i,j) + colSeperator;
				} else {
					copyData += obj.getCellValue(i,j);
				}
			}
		}
		if (i < obj.selectendrow) {
				copyData += "\r\n";
		}
	}

	copyData += "\r\n";
	system.clearClipboard();
	system.setClipboard("CF_TEXT",copyData);


	var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
};

/**
 * @class paste데이터생성
 * @param {String} browser - 브라우저
 * @return paste데이터 
 * @example
 * this._gfnGirdGetPasteData("nexacro");	
*/
//pForm._gfnGirdGetPasteData = function (browser)
//{
//	var copyData = "";
//	if (browser == "nexacro" || browser == "IE")
//	{
//		copyData = system.getClipboard("CF_TEXT");
//		copyData = new String(copyData);
//	}
//	else
//	{
//		var ta = this.tragetGrid["ta"];
//
//		if (!ta) 
//		{
//			return;
//		}
//
//		copyData = ta.value;
//		
//		var ta = this._createTextarea(copyData);
//		nexacro._OnceCallbackTimer.callonce(this, function() {
//			document.body.removeChild(ta);
//		}, 100);
//	}
//	return copyData;
//	
//};

/**
 * @class paste데이터생성
 * @param {String} browser - 브라우저
 * @return paste데이터 
 * @example
 * this._gfnGirdGetPasteData("nexacro");	
*/
pForm._gfnGirdGetPasteData = function (browser)
{
	var copyData = "";
		
	if( browser == "nexacro" || browser == "IE")
	{		
	    copyData = system.getClipboard("CF_TEXT");
		copyData = new String(copyData);
		
	}else{	
		var ta = this.tragetGrid["ta"];

		if(!ta) return;
		
		copyData = ta.value;
		document.body.removeChild(ta);
		
		this.tragetGrid["ta"] = undefined;		
	}
	return copyData;
	
};

///**
// * @class paste event
// * @param {Object} obj- 대상그리드
// * @param {Event}  e - key down event
// * @return N/A
// * @example
// * this._gfnGridPasteEvent(obj, e);	
//*/
//pForm._gfnGridPasteEvent = function (obj, e)
//{
//	var browser = system.navigatorname;
//	var copyData = this._gfnGirdGetPasteData(browser);
//	
//	if (this.gfnIsNull(copyData))
//	{
//		return;
//	}
//	
//	var colSeperator = "\t";
//	var rowData ="";
//	if (browser == "nexacro" || browser =="IE")
//	{
//		rowData = copyData.split("\r\n");
//		if (rowDataCount < 1)
//		{
//			e.stopPropagation();
//			return;
//		}
//	}
//	else
//	{
//		rowData = copyData.split(/[\n\f\r]/); 
//	}
//	var rowDataCount = rowData.length - 1;
//
//			
//	
//	obj.set_enableevent(false);
//	obj.set_enableredraw(false); 
//
//	var datasetName = obj.binddataset;
//	var ds = obj.getBindDataset();
//
//	ds.set_enableevent(false); 
//
//	var grdCellCount = obj.getCellCount("body");
//	var rowCount = ds.getRowCount();
//	
//	var startrow = nexacro.toNumber(obj.selectstartrow);
//	if (startrow == -9)
//	{
//		return;
//	}
//
//	var endrow   = nexacro.toNumber(obj.selectendrow);
//	if (endrow == -9) 
//	{
//		return;
//	}
//	
//	var startcol = 0;
//	var endcol = 0;
//	
//	if (obj.selecttype == "row" || obj.selecttype == "multirow")
//	{
//		startcol = 0;
//		endcol = obj.getCellCount("body")-1;
//	}
//	else
//	{
//		startcol = nexacro.toNumber(obj.selectstartcol);
//		endcol   = nexacro.toNumber(obj.selectendcol);
//	}
//
//	var currRow = startrow;
//	var cellIndex = startcol;
//	var maxColumnCount = 0;
//	var checkIndex = {};	
//
//	for (var i = 0; i < rowDataCount; i++)
//	{
//		if (rowCount <= currRow)
//		{
//			ds.addRow();
//		}
//
//		var columnData = rowData[i].split(colSeperator);
//		var columnLoopCount = cellIndex + columnData.length;
//
//		if (columnLoopCount > grdCellCount) 
//		{
//			columnLoopCount = grdCellCount;
//		}
//
//		if (maxColumnCount < columnLoopCount)
//		{
//			maxColumnCount = columnLoopCount;
//		}
//
//		var k = 0;
//		//--------------------TOBE--------------------
//		var pasteYn_= true;
//		//--------------------------------------------		
//		for (var j = cellIndex; j < columnLoopCount; j++) 
//		{
//			if (obj.getCellProperty("body", j, "displaytype") == "buttoncontrol")
//			{
//				j++;
//				columnLoopCount++;
//			}
//
//			var colTemp = obj.getCellProperty("body", j, "text");
//			//--------------------TOBE--------------------
//			var tobe_ = obj.getCellProperty("body", j, "edittype"); 
//			//-------------------------------------------- 			
//			var colid;
//			if (this.gfnIsNull(colTemp))
//			{
//				colid = obj.getCellProperty("body", j, "text");
//			}
//			else
//			{
//				colid = obj.getCellProperty("body", j, "text").substr(5);
//			}
//			
//			var tempValue = columnData[k];
//			//--------------------TOBE-------------------- 
//			if (!this.gfnIsNull(tempValue) &&  tobe_ != "readonly" && tobe_ != "none" && tobe_ != "button" && tobe_ != "checkbox") //TOBE
//			{
//				ds.setColumn(currRow, colid, tempValue);
//			}
//			else
//			{
//				 pasteYn_= false;
//				//trace(">>>>>>>>>>>>>>>>>>>>>>");
//			}
//			//-------------------------------------------- 
//			k++;
//		}
//		currRow++;
//	}
//
//	ds.rowposition = currRow;	
//
//	endrow = endrow + rowDataCount - 1;
//	endcol = maxColumnCount - 1;
//	
//	system.clearClipboard();
//
//	obj.set_enableredraw(true);
//	obj.set_enableevent(true);
//	ds.set_enableevent(true); 
//
//	//--------------------TOBE-------------------- 
//	if(pasteYn_)
//	{
//		obj.selectArea(startrow, startcol, endrow, endcol);
//	
//		var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
//		e.stopPropagation();
//	}
//	//-------------------------------------------- 
//};

/**
 * @class paste event
 * @param {Object} obj- 대상그리드
 * @param {Event}  e - key down event
 * @return N/A
 * @example
 * this._gfnGridPasteEvent(obj, e);	
 * 수정내용 LFML-52101
*/
pForm._gfnGridPasteEvent = function (obj, e)
{
	var browser = system.navigatorname;	
	var copyData = this._gfnGirdGetPasteData(browser);
	trace("obj.enable:"+obj.enable);
	if(!obj.enable)
	{
		return;
	}
	if(obj.readonly)
	{
		return;
	}
	if( this.gfnIsNull(copyData)){
		var copyData ="";		
		var ta = this._createTextarea("");
		
		nexacro._OnceCallbackTimer.callonce(this, function() {
		
			var colSeperator = "\t";
			var rowData ="";
			if( browser == "nexacro" || browser =="IE"){
				rowData = copyData.split("\r\n");
				if(rowDataCount < 1) {
					e.stopPropagation();
					return;
				}
			}else{
				copyData = ta.value;
				rowData = copyData.split(/[\n\f\r]/); 
			}
			trace("copyData:"+copyData);
			var rowDataCount = rowData.length - 1;					
			
			obj.set_enableevent(false);
			obj.set_enableredraw(false); 

			var datasetName = obj.binddataset;
			var ds = obj.getBindDataset();

			ds.set_enableevent(false); 

			var grdCellCount = obj.getCellCount("body");
			var rowCount = ds.getRowCount();
			
			var startrow = nexacro.toNumber(obj.selectstartrow);
			if( startrow == -9) return;

			var endrow   = nexacro.toNumber(obj.selectendrow);
			if( endrow == -9) return;
			
			var startcol = 0;
			var endcol = 0;
			
			if( obj.selecttype == "row" || obj.selecttype == "multirow"){
				startcol = 0;
				endcol = obj.getCellCount("body")-1;
			}else{
				startcol = nexacro.toNumber(obj.selectstartcol);
				endcol   = nexacro.toNumber(obj.selectendcol);
			}

			var currRow = startrow;
			var cellIndex = startcol;
			var maxColumnCount = 0;
			var checkIndex = {};	

			for (var i = 0; i <= rowDataCount; i++)
			{
				if(rowCount <= currRow)
				{
					//ds.addRow();
				}

				var columnData = rowData[i].split(colSeperator);
				var columnLoopCount = cellIndex + columnData.length;

				if(columnLoopCount > grdCellCount) {
					columnLoopCount = grdCellCount;
				}

				if(maxColumnCount < columnLoopCount) {
					maxColumnCount = columnLoopCount;
				}

				var k = 0;
				for(var j = cellIndex; j < columnLoopCount; j++) 
				{
					var colTemp = obj.getCellProperty("body", j, "text");
					var colid;
					if( this.gfnIsNull(colTemp) )
					{
						colid = obj.getCellProperty("body", j, "text");
					}
					else
					{
						colid = obj.getCellProperty("body", j, "text").substr(5);
					}
					
					var tempValue = columnData[k];
					if(!this.gfnIsNull(tempValue))
					{
						trace("colTemp:"+colTemp);
						trace("edittype:"+obj.getCellPropertyValue(0, j, "edittype" ));
						if(obj.getCellPropertyValue(0, j, "edittype" )!="none")
						{
							ds.setColumn(currRow, colid, tempValue);
						}
					}
					k++;
				}
				currRow++;
			}

			ds.rowposition = currRow;	

			endrow = endrow + rowDataCount - 1;
			endcol = maxColumnCount - 1;
			
			system.clearClipboard();

			obj.set_enableredraw(true);
			obj.set_enableevent(true);
			ds.set_enableevent(true); 

			obj.selectArea(startrow, startcol, endrow, endcol);
			trace("type1 startrow:"+ startrow+ ", startcol:"+ startcol+ ", endrow:"+ endrow+ ", endcol:"+ endcol);
			var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
			e.stopPropagation();				
			
		}, 100);		
		
	
	}else{
	
		var colSeperator = "\t";
		var rowData ="";
		if( browser == "nexacro" || browser =="IE"){
			rowData = copyData.split("\r\n");
			if(rowDataCount < 1) {
				e.stopPropagation();
				return;
			}
		}else{
			rowData = copyData.split(/[\n\f\r]/); 
		}
		var rowDataCount = rowData.length - 1;
		trace("copyData:"+copyData);
				
		
		obj.set_enableevent(false);
		obj.set_enableredraw(false); 

		var datasetName = obj.binddataset;
		var ds = obj.getBindDataset();

		ds.set_enableevent(false); 

		var grdCellCount = obj.getCellCount("body");
		var rowCount = ds.getRowCount();
		
		var startrow = nexacro.toNumber(obj.selectstartrow);
		if( startrow == -9) return;

		var endrow   = nexacro.toNumber(obj.selectendrow);
		if( endrow == -9) return;
		
		var startcol = 0;
		var endcol = 0;
		
		if( obj.selecttype == "row" || obj.selecttype == "multirow"){
			startcol = 0;
			endcol = obj.getCellCount("body")-1;
		}else{
			startcol = nexacro.toNumber(obj.selectstartcol);
			endcol   = nexacro.toNumber(obj.selectendcol);
		}

		var currRow = startrow;
		var cellIndex = startcol;
		var maxColumnCount = 0;
		var checkIndex = {};	

		for (var i = 0; i <= rowDataCount; i++)
		{
			if(rowCount <= currRow)
			{
				//ds.addRow();
			}

			var columnData = rowData[i].split(colSeperator);
			var columnLoopCount = cellIndex + columnData.length;

			if(columnLoopCount > grdCellCount) {
				columnLoopCount = grdCellCount;
			}

			if(maxColumnCount < columnLoopCount) {
				maxColumnCount = columnLoopCount;
			}

			var k = 0;
			for(var j = cellIndex; j < columnLoopCount; j++) 
			{
				var colTemp = obj.getCellProperty("body", j, "text");
				var colid;
				if( this.gfnIsNull(colTemp) )
				{
					colid = obj.getCellProperty("body", j, "text");
				}
				else
				{
					colid = obj.getCellProperty("body", j, "text").substr(5);
				}
				
				var tempValue = columnData[k];
				if(!this.gfnIsNull(tempValue))
				{ 
					if(obj.getCellPropertyValue(0, j, "edittype" )!="none")
					{
						ds.setColumn(currRow, colid, tempValue);
					}
				}
				k++;
			}
			currRow++;
		}

		ds.rowposition = currRow;	

		endrow = endrow + rowDataCount - 1;
		endcol = maxColumnCount - 1;
		
		//system.clearClipboard();

		obj.set_enableredraw(true);
		obj.set_enableevent(true);
		ds.set_enableevent(true); 

		//obj.selectArea(startrow, startcol, endrow, endcol);
		trace("type2 startrow:"+ startrow+ ", startcol:"+ startcol+ ", endrow:"+ endrow+ ", endcol:"+ endcol);
		var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
		e.stopPropagation();	
	}	
};

/**
 * @class copy event(chrome)
 * @param {Object} obj- 대상그리드
 * @param {Event}  e - key down event
 * @return N/A
 * @example
 * this._gfnGridCopyEventForChrome(obj, e);	
*/
//pForm._gfnGridCopyEventForChrome = function (obj, e)
//{
//	var startrow = nexacro.toNumber(obj.selectstartrow);
//	if (startrow == -9) 
//	{
//		return;
//	}
//
//	var endrow   = nexacro.toNumber(obj.selectendrow);
//	if (endrow == -9) 
//	{
//		return;
//	}
//	
//	var startcol = 0;
//	var endcol = 0;
//	
//	if (obj.selecttype == "row" || obj.selecttype == "multirow")
//	{
//		startcol = 0;
//		endcol = obj.getCellCount("body")-1;
//	}
//	else
//	{
//		startcol = nexacro.toNumber(obj.selectstartcol);
//		endcol   = nexacro.toNumber(obj.selectendcol);
//	}
//
//	var colSeperator = "\t";
//	var copyData = "";
//	
//	for (var i = startrow; i <= endrow; i++) 
//	{
//		for (var j = startcol; j <= endcol; j++) 
//		{
//			if (obj.getCellProperty("body", j, "displaytype") != "buttoncontrol")
//			{
//				var value = obj.getCellValue(i,j);
//				if (!this.gfnIsNull(value)) 
//				{
//					if (j < endcol)
//					{
//						copyData += obj.getCellValue(i,j) + colSeperator;
//					}
//					else
//					{
//						copyData += obj.getCellValue(i,j);
//					}
//				}
//			}
//		}
//		if (i < obj.selectendrow)
//		{
//				copyData += "\r\n";
//		}
//	}
//
//	copyData += "\r\n";
//	
//	var ta = this._createTextarea(copyData);
//	nexacro._OnceCallbackTimer.callonce(this, function() {
//		document.body.removeChild(ta);
//	}, 100);
//	this.tragetGrid = obj;
//	this.tragetGrid["ta"] = ta;
//	var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
//	e.stopPropagation();
//};

/**
 * @class copy event(chrome)
 * @param {Object} obj- 대상그리드
 * @param {Event}  e - key down event
 * @return N/A
 * @example
 * this._gfnGridCopyEventForChrome(obj, e);	
*/
pForm._gfnGridCopyEventForChrome = function (obj, e)
{
	var startrow = nexacro.toNumber(obj.selectstartrow);
	if( startrow == -9) return;

	var endrow   = nexacro.toNumber(obj.selectendrow);
	if( endrow == -9) return;
	
	var startcol = 0;
	var endcol = 0;
	
	if( obj.selecttype == "row" || obj.selecttype == "multirow"){
		startcol = 0;
		endcol = obj.getCellCount("body")-1;
	}else{
		startcol = nexacro.toNumber(obj.selectstartcol);
		endcol   = nexacro.toNumber(obj.selectendcol);
	}

	var colSeperator = "\t";
	var copyData = "";
	
	for (var i = startrow; i <= endrow; i++) {
		for (var j = startcol; j <= endcol; j++) {
			var value = obj.getCellValue(i,j);
			if(!this.gfnIsNull(value)) {
				if (j < endcol) {
					copyData += obj.getCellValue(i,j) + colSeperator;
				} else {
					copyData += obj.getCellValue(i,j);
				}
			}
		}
		if (i < obj.selectendrow) {
				copyData += "\r\n";
		}
	}

	copyData += "\r\n";
	
	var ta = this._createTextarea(copyData);
	this.tragetGrid = obj;
	this.tragetGrid["ta"] = ta;
	var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
	e.stopPropagation();
};

/**
 * @class cell copy and paste (크롬용 텍스트에어리어생성)
 * @param {String} innerText- value
 * @return{Object} 텍스트에어리어 오브젝트
 * @example
 * this._createTextarea("꼬부기");	
*/
//pForm._createTextarea = function(innerText)
//{
//	var ta = document.createElement('textarea');
//	ta.id = "textAreabyCopyAndPaste";
//	ta.style.position = 'absolute';
//	ta.style.left = '-1000px';
//	ta.style.top = document.body.scrollTop + 'px';
//	ta.value = innerText;
//	
//	document.body.appendChild(ta);
//	ta.select();
//	if (document.execCommand)
//	{
//		document.execCommand('copy');
//	}
//	
//	return ta;
//};

/**
 * @class cell copy and paste (크롬용 텍스트에어리어생성)
 * @param {String} innerText- value
 * @return{Object} 텍스트에어리어 오브젝트
 * @example
 * this._createTextarea("꼬부기");	
*/
pForm._createTextarea = function(innerText)
{
	var browser = system.navigatorname;
	if( browser == "nexacro" || browser =="IE"){
		return "";
	}
	
	var ta = document.createElement('textarea');
	ta.id = "textAreabyCopyAndPaste";
	ta.style.position = 'absolute';
	ta.style.left = '-1000px';
	ta.style.top = document.body.scrollTop + 'px';
	ta.value = innerText;
	
	document.body.appendChild(ta);
	ta.select();
	document.execCommand("copy"); 
	return ta;
};

/**
 * @class head cell에 match되는 body cell을 얻어온다
 * @param {Object}  grid 대상 Grid Component
 * @param {Number} eadCellIndex head cell index
 * @return{Number}  body cell index
 * @example
 * this._gfnGridSetSortStatus(obj, e.cell, multiple);	
 */ 
pForm._gfnGridGetBodyCellIndex = function(grid, headCellIndex, useColspan) 
{	//, useColspan) 
	if (this.gfnIsNull(useColspan))
	{
		useColspan=false;
	}
	// Max Head Row Index
	var maxHeadRow = 0;
	for (var i=0, len=grid.getCellCount("head"); i<len; i++) 
	{
		var row = grid.getCellProperty("head", i, "row");
		if (maxHeadRow < row)
		{
			maxHeadRow = row;
		}
	}
	// Max Body Row Index
	var maxBodyRow = 0;
	for (var i=0, len=grid.getCellCount("body"); i<len; i++)
	{
		var row = grid.getCellProperty("body", i, "row");
		if (maxBodyRow < row)
		{
			maxBodyRow = row;
		}
	}
	
	if (maxHeadRow == 0 && maxBodyRow == 0)
	{
// 		var headcolspan = grid.getCellProperty("head", headCellIndex, "colspan");
// 		var bodycolspan = grid.getCellProperty("body", headCellIndex, "colspan");
// 		
// 		if( headcolspan == bodycolspan ){
// 			return headCellIndex;
// 		}
		useColspan = true;
	}
	
	// Body Row 가 1개 이상일 경우
	// Head의 row 가 Body의 row 보다 클 경우 차이 row 를 뺀 것을 대상으로 찾고
	// Body의 row 가 Head의 row 보다 크거나 같을 경우 row index가 같은 대상을 찾는다.			
	var cellIndex = -1;
	var sRow = -1;
	var nRow = parseInt(grid.getCellProperty("head", headCellIndex, "row"));
	var nCol = parseInt(grid.getCellProperty("head", headCellIndex, "col"));
	var nColspan = parseInt(grid.getCellProperty("head", headCellIndex, "colspan"));				
	
	if (maxHeadRow > maxBodyRow) 
	{
		sRow = nRow - (maxHeadRow - maxBodyRow);
		sRow = (sRow < 0 ? 0 : sRow);
	}
	else 
	{
		sRow = nRow;
	}
	var cRow, cCol, cColspan, cRowspan;
	for (var i=0, len=grid.getCellCount("body"); i<len; i++) 
	{
		cRow = parseInt(grid.getCellProperty("body", i, "row"));
		cCol = parseInt(grid.getCellProperty("body", i, "col"));	
		cColspan = parseInt(grid.getCellProperty("body", i, "colspan"));					
		cRowspan = parseInt(grid.getCellProperty("body", i, "rowspan"));
		if( cRowspan > 1 )
		{
			if (useColspan)
			{
				if (sRow >= cRow && nCol <= cCol && cCol < (nCol + nColspan)) 
				{		
					cellIndex = i;
					break;
				}		
			}
			else
			{
				if (sRow >= cRow && nCol == cCol && nColspan == cColspan) 
				{		
					cellIndex = i;
					break;
				}
			}
		}
		else
		{	
			if (useColspan)
			{
				if (sRow == cRow && nCol <= cCol && cCol < (nCol + nColspan)) 
				{		
					cellIndex = i;
					break;
				}		
			}
			else
			{
				if (sRow == cRow && nCol == cCol && nColspan == cColspan) 
				{		
					cellIndex = i;
					break;
				}
			}
		}
	}
	return cellIndex;
};

/**
 * @class body cell index로 binding 된 컬럼명을 얻어온다.
 * @param {Object}  grid 대상 Grid Component
 * @param {Number} eadCellIndex head cell index
 * @return{String} column id
 * @example
 * this._gfnGridGetBindColumnNameByIndex(obj, e.cell);	
 */  
pForm._gfnGridGetBindColumnNameByIndex = function(grid, index) 
{
	var text = "";
	var columnid = "";
	var subCell = grid.getCellProperty("body", index, "subcell");
	if (subCell > 0)
	{
		text = grid.getSubCellProperty("body", index, 0, "text");
	}
	else
	{
		text = grid.getCellProperty("body", index, "text");
	}
	
	if (!this.gfnIsNull(text))
	{
		if (text.search(/^BIND\(/) > -1)
		{	
			columnid = text.replace(/^BIND\(/, "");
			columnid = columnid.substr(0, columnid.length-1);
		} 
		else if (text.search(/^bind:/) > -1)
		{
			columnid = text.replace(/^bind:/, "");
		}
	}
	return columnid;
};
//////////////////////////////////////////////////////////////////////////Popupmenu//////////////////////////////////////////////////////////////////////////
/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
		  셀고정(colfix)
 * @param {Object} objGrid  - 대상그리드
 * @param {Number} nCellIdx - 셀고정 셀인덱스
 * @param {Number} nRowIdx  - 셀고정 로우 인덱스
 * @return N/A
 * @example
 * this._gfnGridcellFix(this.grdMain, 1, 2);	
 */
pForm._gfnGridcellFix = function (objGrid, nCellIdx, nRowIdx)
{
	var sBandType;
	if (nRowIdx == -1) 
	{
		sBandType = "Head";
	}
	else if (nRowIdx == -2)
	{
		sBandType = "Summary";
	}
	else
	{
		sBandType = "Body";
	}
	
	var nCol 	 = nexacro.toNumber(objGrid.getCellProperty(sBandType, nCellIdx, "col"));
	var nColSpan = nexacro.toNumber(objGrid.getCellProperty(sBandType, nCellIdx, "colspan"));
	var nRowSpan = nexacro.toNumber(objGrid.getCellProperty(sBandType, nCellIdx, "rowspan"));
	var nVal = objGrid.getCellpos
	var nMaxCol = 0;
	var i;
	var nRealCol;
	var nRealColSpan;
	var nRealCol_end;
	
	objGrid.set_enableredraw(false);
	
	objGrid.setFormatColProperty(0, "band", "body");	
	
	for (i=0; i<objGrid.getCellCount("Head"); i++)
	{
		nRealCol = nexacro.toNumber(objGrid.getCellProperty("Head", i, "col"));
		nRealColSpan = nexacro.toNumber(objGrid.getCellProperty("Head", i, "colspan"));
		nRealCol_end = nRealCol+nRealColSpan-1;
		if (nRealCol == nCol||nRealCol_end==nCol)
		{
			if (nRealColSpan>1)
			{
				//objGrid.setCellProperty("Head", i, "line", "1 solid #dcdbdaff,2 solid #919191ff");
				nCol = nRealCol_end;
			}
			else
			{
				//objGrid.setCellProperty("Head", i, "line", "1 solid #dcdbdaff,2 solid #919191ff");
				nCol = nRealCol_end;
			}
		}
		else
		{
			objGrid.setCellProperty("Head", i, "line", "");
		}
	}
	
	for (i=0; i<objGrid.getCellCount("Body"); i++)
	{
		if (objGrid.getCellProperty("Body", i, "col") == nCol)
		{
			//objGrid.setCellProperty("Body", i, "line", "1 solid #dcdbdaff,2 solid #919191ff");
			objGrid.setCellProperty("Body", i, "border", "1px solid #dbdee2 , 2px solid aqua , 1px solid #dbdee2 , 1px solid #dbdee2");
		}
		else
		{
			//objGrid.setCellProperty("Body", i, "line", "");
			objGrid.setCellProperty("Body", i, "border", "");
		}
	}	
	
	objGrid.setFormatColProperty(nCol, "band", "left");	
	objGrid.set_enableredraw(true);
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
		  셀고정해제(colfree)
 * @param {Object} objGrid - 대상그리드
 * @return N/A
 * @example
 * this._gfnGridCellFree(this.grdMain);	
 */
pForm._gfnGridCellFree = function(objGrid)
{
	for (i=0; i< objGrid.getFormatColCount(); i++)
	{		
		objGrid.setFormatColProperty(i, "band", "body");	
	}
		
	for (i=0; i<objGrid.getCellCount("Body"); i++)
	{
		objGrid.setCellProperty("Body", i, "border", "");
	}	
	
	this.gv_CellIndex = -1;
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          셀필터(cellFilter)
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCell - 셀필터 셀 인덱스
 * @return N/A
 * @example
 * this._gfnGridFilter(this.grdMain);	
 */
pForm._gfnGridFilter = function(objGrid)
{
	var sTitle = this.gfnGetWord("popup.datafiltersetting");
	var oArg = {pvGrid:objGrid};
	
	var oOption = {title:sTitle};	//top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	var sPopupCallBack = "gfnGridFilterCallback";
	this.gfnOpenPopup( "cmmGridFilter", "Common::cmmGridFilter.xfdl",oArg, sPopupCallBack, oOption);	
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          셀필터해제(cellfilterfree)
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCell - 셀필터 셀 인덱스
 * @return N/A
 * @example
 * this._gfnGridCellFilterFree(this.grdMain);	
 */
pForm._gfnGridCellFilterFree = function(objGrid)
{
	var objDs = objGrid.getBindDataset();
	objDs.set_filterstr("");
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          찾기/바꾸기
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCell - 셀필터 셀 인덱스
 * @return N/A
 * @example
 * this._gfnGridCellReplace(this.grdMain);	
 */
pForm._gfnGridCellReplace = function(objGrid,nCellIndex,nRowIndex)
{
	var sTitle = this.gfnGetWord("popup.datafindreplace");
	var orgselecttype = objGrid.selecttype;

	var oArg = {pvGrid:objGrid, pvStrartRow:nRowIndex, pvSelectCell:nCellIndex, pvSelectType:orgselecttype};
	var oOption = {title:sTitle};	//top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	var sPopupCallBack = "gfnReplaceCallback";
	this.gfnOpenPopup( "cmmFindReplace","Common::cmmFindReplace.xfdl",oArg,sPopupCallBack,oOption);	
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          컬럼 숨기기/보이기
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCell - 셀필터 셀 인덱스
 * @return N/A
 * @example
 * this._gfnGridColHideShow(this.grdMain);	
 */
pForm._gfnGridColHideShow = function(objGrid)
{
	var sTitle = this.gfnGetWord("popup.colshwohide");
	
	var oArg = {pvGrid:objGrid};
	var oOption = {title:sTitle};	//top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	var sPopupCallBack = "gfnColumnHidCallback";
	this.gfnOpenPopup( "cmmColumnHide","Common::cmmColumnHide.xfdl",oArg,sPopupCallBack,oOption);	
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          엑셀익스포트
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this._gfnGridExcelExport(this.grdMain);	
 */
pForm._gfnGridExcelExport = function(objGrid)
{
	this.gfnExcelExport(objGrid, "*?*?*?*?*?*?*?","");
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          엑셀임포트
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this._gfnGridExcelImport(this.grdMain);	
 */
pForm._gfnGridExcelImport = function(objGrid)
{
	var sDataset = objGrid.binddataset;
	this.gfnExcelImport(sDataset, "sheet1", "A2", "fnImportCallback", objGrid.name + sDataset , this);
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this._gfnGridPersonalize(this.grdMain);	
 */
pForm._gfnGridPersonalize = function(objGrid)
{
	var sOrgFormat = objGrid.orgformat2;
	var sCurFormat = objGrid.getCurFormatString();
	this._gfnGridPersonalizeExcute(objGrid);
//	//변경된 사항 확인 할 경우 아래 스크립트 사용
// 	if( sOrgFormat == sCurFormat ){
// 		this.gfnAlert("msg.save.nochange","","NoChangeFormat");
// 	}else{
// 		var sId = "ChangeFormat|" + objGrid.name;
// 		this.gfnAlert("confirm.before.save","", sId, "gfnGridFormatChangeMsgCallback");
// 	}
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화실행.
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this._gfnGridPersonalize(this.grdMain);	
 */
pForm._gfnGridPersonalizeExcute = function (objGrid)
{
	var sFormatId 	= this._getUniqueId(objGrid);
	var sFormat 	= objGrid.getCurFormatString(false);
	var sOrgFormats = objGrid.getFormatString();

	var objApp = pForm.gfnGetApplication();
	var objGds = objApp.gdsGridPersonal;
	
	var nFindRow = objGds.findRow("sFormatId", sFormatId);
	if (nFindRow == -1)
	{
		var nRow = objGds.addRow();
		objGds.setColumn(nRow, "sFormatId", sFormatId);
		objGds.setColumn(nRow, "sFormat", sFormat);
		objGds.setColumn(nRow, "sOrgFormat", sOrgFormats);
	}
	else
	{
		objGds.setColumn(nFindRow, "sFormat", sFormat);
		//objGds.setColumn(nFindRow, "sOrgFormat", sOrgFormats);
	}
	var sXML = objGds.saveXML();
	nexacro.setPrivateProfile("gdsGridPersonal", sXML);	
	this.gfnAlert("msg.save.success","","saveSuccess","gfnGridFormatChangeMsgCallback");
};
//////////////////////////////////////////////////////////////////////////POPUPMENU CALLBACK///////////////////////////////////////////////////////////

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화 메세지콜백
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnGridFormatChangeFormatCallback("TEST", "");	
 */
pForm.gfnGridFormatChangeMsgCallback = function (sid, rtn)
{
	//TODO.
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 찾기/바꾸기 팝업 콜백
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnReplaceCallback("TEST", "");	
 */
pForm.gfnReplaceCallback = function (sid, rtn)
{
	//TODO
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 필터 팝업 콜백
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnGridFilterCallback("TEST", "");	
 */
pForm.gfnGridFilterCallback = function (sid, rtn)
{
	//TODO
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 컬럼숨기기/보이기
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnColumnHidCallback("TEST", "");	
 */
pForm.gfnColumnHidCallback = function (sid, rtn)
{
	//TODO
};

//////////////////////////////////////////////////////////////////////////POPUPMENU FUNCTION///////////////////////////////////////////////////////////
/**
 * @class   주어진 문자열을 그리드에서 찾는다.
 * @param {Object} grid - 대상그리드	
 * @param {String} findText - 찾을 문자열	
 * @param {Object} option - 찾기옵션	
 * @return {Object} 찾은 열과행
 * @example
 * this.gfnFindGridText(this.fv_grid, txt, option);
 */
pForm.gfnFindGridText = function (grid, findText, option)
{
	grid.lastFindText = findText;
	grid.lastFindOption = option;

	// 찾을 옵션
	var direction = option.direction;
	var position = option.position;
	var scope = option.scope;
	var condition = option.condition;
	var strict = option.strict;

	var dataset = grid.getBindDataset();
	var startCell = ( position == "current" ? grid.currentcell : grid.lastFindCell );
	var startRow = ( position == "current" ? grid.currentrow : grid.lastFindRow );
	
	// 바꾸기에서 호출시 (option.cell 은 바꾸기에서만 지정)
	if ( scope == "col" && !this.gfnIsNull(option.cell) )
	{
		startCell = option.cell;
	}
	
	var findRow = findCell = -1;
	var rowCnt = dataset.rowcount;
	var bodyCellCnt = grid.getCellCount("body");
			
	// 대소문자 구분
	if ( !strict )
	{
		findText = findText.toUpperCase();			
	}
		
	if ( direction == "prev" )
	{
		startRow -= 1;	
		if ( startRow < 0 )
		{
			startRow = rowCnt-1;
		}
	}
	else
	{
		startRow += 1;
		if ( startRow >= rowCnt )
		{
			startRow = 0;
		}
	}
	
	var loopCnt = rowCnt;
	while ( loopCnt > 0 )
	{
		// 문자열 비교
		if (this._compareFindText(grid, startRow, startCell, findText, condition, strict) )
		{
			findRow = startRow;
			findCell = startCell;
			break;
		}
		
		// 방향 (이전, 다음)
		if ( direction == "prev" )
		{
			startRow -= 1;
			if ( startRow < 0 )
			{
				startRow = rowCnt-1;
			}				
		}
		else
		{
			startRow += 1;
			if ( startRow > (rowCnt-1) )
			{
				startRow = 0;
			}
		}
		
		loopCnt--;
	}
	
	// 마지막 찾은 위치 지정
	// 팝업에서 찾을 방향을 "처음부터" 로 변경 시 초기화
	if ( findRow > -1 && findCell > -1 )
	{
		grid.lastFindRow = findRow;
		grid.lastFindCell = findCell;
	}
	
	return [findRow, findCell];
};

/**
 * @class  _gfnGridSetCssclass 행고정/해제시 css설정
 * @param {Object} objGrid	- 대상그리드
 * @return N/A
 * @example
 * this._gfnGridSetCssclass(this.grdMain);	
 */
pForm._gfnGridSetCssclass = function (objGrid)
{
	var clname = "Cell_WF_Fixed";
	clname = nexacro.wrapQuote(clname);
			
	objGrid.set_enableredraw(false);

	for( var k=0; k<objGrid.getFormatColCount(); k++){
		var expr = "";
		if( objGrid.fixedRow >= 0 ){
			expr = "expr:comp.fixedRow==currow?"+clname+":''";
		}
		objGrid.setCellProperty("body", k, "cssclass", expr);
	}
	objGrid.set_enableredraw(true);
	objGrid.setFixedRow(objGrid.fixedRow);
};

/**
 * Cell object 를 반환 (Grid 내부 속성이므로 get 용도로만 사용)
 * @param {Grid} grid 대상 Grid Component
 * @param {string} band 얻고자 하는 cell 의 band (head/body/summ);
 * @param {number} index 얻고자 하는 cell 의 index
 * @return {object} cell object
 */
pForm._gfnGridGetGridCellObject = function(grid, band, index)
{
	// 내부속성을 통해 얻어온다.
	var refCell;
	var format = grid._curFormat;
	if (format){
		if ( band == "head" ){
			refCell = format._headcells[index];
		}
		else if ( band == "body" ){
			refCell = format._bodycells[index];
		}
		else if ( band == "summ" || band == "summary" ){
			refCell = format._summcells[index];
		}
	}
	return refCell;
};

/**
 * @class 유저헤더사용여부반환
 * @param {Object} objGrid - 대상그리드
 * @return 유저헤더사용여부 true/false
 * @example
 * this._gfnGridUserHeaderFlg(this.grdMain);
 */
pForm._gfnGridUserHeaderFlg = function (objGrid)
{
	var arr = objGrid.arrprop;
	var bUserHeader = false;
	for (var i=0; i<arr.length; i++)
	{
		if (arr[i] == "userheader")
		{
			bUserHeader = true;
		}
	}
	return bUserHeader;
};

/**
 * @class 줄임말 표시
 * @param {Object} obj - 대상그리드
 * @param {String} sValue - 치환하고자하는 Value
 * @param {Number} nColIdx - 대상 Column Index
 * @return {String} sRtn
 * @example
 * this.gfnSetCellText(this.grid, "Test Text", 0);
 *   ==> expr:comp.parent.gfnSetCellText(comp, Column0, this.col)
 */
pForm.gfnSetCellText = function(obj, sValue, nColIdx)
{
	var sRtn = sValue;
	var nSize = nexacro.toNumber(obj.getFormatColProperty(nColIdx, "size"))/12;

	if (sValue.length > nSize)
	{
		sRtn = sValue.substr(0,nSize) + "...";
	} 
	
	return sRtn;
};

/**
 * @class 데이터 찾기
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCell - 셀필터 셀 인덱스
 * @return N/A
 * @example
 * this._gfnGridCellFind(this.grdMain);	
 */
pForm._gfnGridCellFind = function(objGrid)
{
	var sTitle = this.gfnGetWord("popup.datafind");
	var orgselecttype = objGrid.selecttype;

	var oArg = {pvGrid:objGrid, pvSelectType:orgselecttype};
	var oOption = {title:sTitle};	//top, left를 지정하지 않으면 가운데정렬 //"top=20,left=370"
	this.gfnOpenPopup( "cmmFind","Common::cmmFind.xfdl", oArg, "", oOption);	
};

 /**
 * @class   주어진 행, 셀 인덱스에 해당하는 그리드 데이터와 <br>
 * 문자열을 비교하여 찾아진 결과를 반환
 * @param {Object} grid - 대상 Grid Component
 * @param {Number} row - 찾을 행 인덱스
 * @param {Number} cell - 찾을 셀 인덱스
 * @param {String} findText - 찾을 문자열
 * @param {String} condition - 찾을 조건(equal/inclusion)
 * @param {Boolean} strict - 대소문자 구분 (true/false)
 * @return {Boolean} - 찾기 성공.
 * @example
 * this._compareFindText(grid, startRow, startCell, findText, condition, strict) 
 */
pForm._compareFindText = function(grid, row, cell, findText, condition, strict)
{
	var cellText = grid.getCellText(row, cell);
	if( this.gfnIsNull(cellText))return;
	var displayType = grid.getCellProperty("body", cell, "displaytype");
		
	// displayType 이 normal일 경우
	// dataType 을 체크하여 displayType 을 변경
	if ( this.gfnIsNull(displayType) || displayType == "normal" )
	{
	
		var dataType = this.gfnGetBindColumnType(grid, cell);
		switch(dataType)
		{
			case 'INT' :
			case 'FLOAT' :
			case 'BIGDECIMAL' :
				displayType = "number";
				break;
			case 'DATE' :
			case 'DATETIME' :
			case 'TIME' :
				displayType = "date";
				break;
			default :
				displayType = "string";
		}
	}
	
	// currency 의 경우 원(￦) 표시와 역슬레시(\) 다르므로 제거 후 비교
	if ( displayType == "currency" )
	{
		var code = cellText.charCodeAt(0);
		if ( code == 65510 || code == 92 )
		{
			cellText = cellText.substr(1);
		}
		
		code = findText.charCodeAt(0);
		if ( code == 65510 || code == 92 )
		{
			findText = findText.substr(1);
		}
	}

	// 대소문자 구분
	if ( !strict )
	{
		cellText = cellText.toUpperCase();
	}
	
	// 일치/포함
	if ( condition == "equal" )
	{
		if ( findText == cellText )
		{
			return true;
		}
	}
	else 
	{
		if ( cellText.indexOf(findText) > -1 )
		{			
			return true;
		}
	}

	return false;
};

 /**
 * @class   데이터의 타입반환
 * @param {Object} grid - 대상 Grid Component
 * @param {Number} cell - 찾을 셀 
 * @return {Object} - 찾기 성공.
 * @example
 *  this.gfnGetBindColumnType(grid, cell);
 */
pForm.gfnGetBindColumnType = function(grid, cell)
{
	var dataType = null;
	var dataset = this.gfnLookup(grid.parent, grid.binddataset);
	var bindColid = grid.getCellProperty("body", cell, "text");
		bindColid = bindColid.replace("bind:", "");

	if ( !this.gfnIsNull(bindColid) )
	{
		var colInfo = dataset.getColumnInfo(bindColid);
		if ( !this.gfnIsNull(colInfo) )
		{
			dataType = colInfo.type;
		}
	}
	
	return dataType;
};

 /**
 * @class   PopupDiv 띄우기
 * @param {Object} obj - 대상 Grid Component
 * @param {Object} e - Event Object
 * @param {String} sType - 구분자 [Text : TextArea, Image : Image]
 * @param {String} sUrl - Image 인 경우 Image 경로
 * @return 
 * @example
 *  this.gfnGridPopupDiv(obj, e, "Text");
 *  this.gfnGridPopupDiv(obj, e, "Image", sUrl);
 */
pForm.gfnGridPopupDiv = function(obj, e, sType, sUrl)
{
	var objForm = this.gfnGetChildFrame(obj);
	
	if (sType == "Text")
	{
		var sPopupDivName = obj.name + sType;
		
		if (this.gfnIsNull(this.gfnFindObj(this, sPopupDivName))) 
		{
			tobjPopupDiv = new PopupDiv();
			tobjPopupDiv.init(sPopupDivName, 0, 0, 160, 70, null, null);	    
			this.addChild(tobjPopupDiv.name, tobjPopupDiv);
			
			objTextArea = new TextArea();
			objTextArea.init("textCell", 0, 0, null, null, 0, 0);	    
			tobjPopupDiv.form.addChild(objTextArea.name, objTextArea);
		}

		tobjPopupDiv.show();
		objTextArea.show();

		var arrCellRect = obj.getCellRect(e.row, e.col-1); 
		var arrCellRectOrg = obj.getCellRect(e.row, e.col); 
		var nTitlebar = objForm.parent.titlebarheight;

		if (this.gfnIsNull(nTitlebar))
		{
			var nLeft = system.clientToScreenX(obj, arrCellRect.left) - system.clientToScreenX(objForm, 0); 
			var nTop = system.clientToScreenY(obj, arrCellRect.bottom) - system.clientToScreenY(objForm, 0); 
			nTop += 20;
			var nWidth = system.clientToScreenX(obj, arrCellRectOrg.left) - system.clientToScreenX(objForm, 0) - nLeft + obj.getRealColSize(e.col);
		}
		else
		{
			var nLeft = system.clientToScreenX(obj, arrCellRect.left) - system.clientToScreenX(nexacro.getApplication().mainframe, 0); 
			var nTop = system.clientToScreenY(obj, arrCellRect.bottom) - system.clientToScreenY(nexacro.getApplication().mainframe, 0); 
			var nWidth = system.clientToScreenX(obj, arrCellRectOrg.left) - system.clientToScreenX(nexacro.getApplication().mainframe, 0) - nLeft + obj.getRealColSize(e.col);
		}
		var sText = obj.getCellText(e.row, e.col-1);
		objTextArea.set_readonly(true);
		objTextArea.set_wordWrap("char");
		objTextArea.set_value(sText);

		tobjPopupDiv.trackPopup(nLeft, nTop, nWidth);
	}
	else if (sType == "Image")
	{
		var sPopupDivName = obj.name + sType;
		
		if (this.gfnIsNull(this.gfnFindObj(this, sPopupDivName))) 
		{
			iobjPopupDiv = new PopupDiv();
			iobjPopupDiv.init(sPopupDivName, 0, 0, 110, 110, null, null);	    
			this.addChild(iobjPopupDiv.name, iobjPopupDiv);
			
			objImageViewer = new ImageViewer();
			objImageViewer.init("imageCell", 0, 0, null, null, 0, 0);	    
			iobjPopupDiv.form.addChild(objImageViewer.name, objImageViewer);
		}

		iobjPopupDiv.show();
		objImageViewer.show();

		var arrCellRect = obj.getCellRect(e.row, e.col); 
		var arrCellRectOrg = obj.getCellRect(e.row, e.col); 
		var nTitlebar = objForm.parent.titlebarheight;

		if (this.gfnIsNull(nTitlebar))
		{
			var nLeft = system.clientToScreenX(obj, arrCellRect.left) - system.clientToScreenX(objForm, 0); 
			var nTop = system.clientToScreenY(obj, arrCellRect.bottom) - system.clientToScreenY(objForm, 0); 
			nTop += 20;
		}
		else
		{
			var nLeft = system.clientToScreenX(obj, arrCellRect.left) - system.clientToScreenX(nexacro.getApplication().mainframe, 0); 
			var nTop = system.clientToScreenY(obj, arrCellRect.bottom) - system.clientToScreenY(nexacro.getApplication().mainframe, 0); 
		}
		objImageViewer.set_image(sUrl);

		iobjPopupDiv.trackPopup(nLeft-110, nTop-110, 110);
	}
};


pForm.gfnExcelMenu_onclick = function(objStc, e)
{
	var objGrid = objStc.parent.parent.targetGrid;
	if (this.gfnIsNull(objGrid)) {
		objGrid = lvGridNm[0];
	}
	if (!objGrid && !this[objGrid.id] && !this[objGrid.id] instanceof Grid) return;
	this.gfnExcelDownload(objGrid);
};

pForm.gfnExcelDownload = function(objGrid) {
	if (!this[objGrid.id] && !this[objGrid.id] instanceof Grid) return;
	// 데이터가 존재할 경우 엑셀다운로드 실행
	var bindDataset = objGrid.getBindDataset();
	try {
		if (bindDataset.rowcount > 0){
			objGrid.set_formatid("excel");
			if (objGrid.getFormatColCount() == 0) {
				//throw {toString: function() { return "해당 그리드에 excel 포멧이 없습니다."; } };
				objGrid.set_formatid("default");
			}
 			var frame = this.getOwnerFrame();
			var fileName  = objGrid.fileName  || this.name.replace(/(.*::)?frm(\w*)(\.xfdl)?/i, "$2") || (frame && frame.MENU_ID) || (frame && frame.arguments && frame.arguments["MENU_NM"]) || this.PROG_ID; 
			var sheetName = objGrid.sheetName || this.titletext || (frame && frame.MENU_ID) || (frame && frame.arguments && frame.arguments["MENU_URL"].replace(/.*::frm(\w*)\.xfdl/gi, "$1")) + "_" + this.gfnGetDate("milli")  || this.PROG_ID;
			this.gfnExcelExport(objGrid, fileName, sheetName);
		} else {
			this.gfnMessage("엑셀 다운로드할 데이터가 존재하지 않습니다.", "A");
		}
	} catch (error) {
		this.gfnMessage(error, "A");
	} finally {
		objGrid.set_formatid("default");
	}
};

//그리드 선택영역 합산
pForm.gfnCellSum = function (objGrid, e)
{
	if (objGrid === undefined) {
		trace("There is no objGrid on this funciton calling..");
		return null;
	}
	
	var isTreeGrid = false;
				
	if (objGrid.rowcount > 0 && objGrid.getCellCount("body")-1 > 0) {
		for (var j=0;j<objGrid.getCellCount("body")-1;j++) {
			var displayType = objGrid.getCellProperty( "body", j, "displaytype" );
 			if (displayType.indexOf("tree") > -1) {
 				isTreeGrid = true;
				break;
 			}
		}
	}
	//트리 그리드 형태일 경우 임시로 합계 계산 disable
	if (isTreeGrid) return null;
	
	var selectedRows=[];
	var selectedCols=[];
	
	var startrow = nexacro.toNumber(objGrid.selectstartrow.length>0?objGrid.selectstartrow.slice()[0]:objGrid.selectstartrow);
	if( startrow == -9) return;

	var endrow   = nexacro.toNumber(objGrid.selectendrow.length>0?objGrid.selectendrow.slice()[objGrid.selectendrow.length-1]:objGrid.selectendrow);
	if( endrow == -9) return;
	
	var startcol = nexacro.toNumber(objGrid.selectstartcol.length>0?objGrid.selectstartcol.slice()[0]:objGrid.selectstartcol);
	var endcol   = nexacro.toNumber(objGrid.selectendcol.length>0?objGrid.selectendcol.slice()[objGrid.selectendcol.length-1]:objGrid.selectendcol);

	var copyData = "";
	var sumData = 0;
	
	if (objGrid.selectstartrow.length > 1 || isTreeGrid) {
		var diffIdxs = [];
		if (isTreeGrid) {
// 			var iCnt = 0;
// 			for (var idx=0; idx<objGrid.selectstartrow.length; idx++) {
// 				if (objGrid.selectstartrow[idx] == objGrid.selectendrow[idx]) {
// 					if (objGrid.getSelectedRows()[selectedRows.length+idx+iCnt] > -1) {
// 						selectedRows.push(objGrid.getSelectedRows()[selectedRows.length+idx+iCnt]);
// 						selectedCols.push(objGrid.selectstartcol[idx]);
// 					}
// 					iCnt = 1;
// 				} else {
// 					var iRow = selectedRows.length;
// 					var eRow = selectedRows.length + objGrid.selectendrow[idx] - objGrid.selectstartrow[idx] + 1;
// 					iCnt = 0;
// 					for (iRow; iRow < eRow; iRow++) {
// 						if (objGrid.getSelectedRows()[iRow] > -1) {
// 							if (objGrid.selectstartcol.length == objGrid.selectendcol.length) {
// 								if (objGrid.selectstartcol[idx] == objGrid.selectendcol[idx]) {
// 									selectedRows.push(objGrid.getSelectedRows()[iRow]);
// 									selectedCols.push(objGrid.selectstartcol[idx]);
// 								} else {
// 									for (var nCol=objGrid.selectstartcol[idx];nCol<=objGrid.selectendcol[idx];nCol++) {
// 										selectedRows.push(objGrid.getSelectedRows()[iRow]);
// 										selectedCols.push(nCol);
// 									}
// 								}
// 							}
// 							iCnt++;
// 						}
// 					}
// 					if (iCnt > 1) iCnt--;
// 				}
// 			}
			console.log("objGrid.selectstartrow="+objGrid.selectstartrow);
			console.log("objGrid.selectendrow="+objGrid.selectendrow);
			console.log("objGrid.selectstartcol="+objGrid.selectstartcol);
			console.log("objGrid.selectendcol="+objGrid.selectendcol);
			objGrid.getSelectedRows().forEach(function(nRow, index){if(nRow > -1)  console.log("["+index+"] "+nRow);});
		} else {
			for (var idx=0;idx<objGrid.selectstartrow.length;idx++) {
				if (objGrid.selectstartrow[idx] == objGrid.selectendrow[idx]) {
					selectedRows.push(objGrid.selectstartrow[idx]);
				} else {
					diffIdxs.push(idx);
					for (var i=objGrid.selectstartrow[idx];i<=objGrid.selectendrow[idx];i++) {
						selectedRows.push(i);
					}
				}
			}
			for (var idx=0;idx<objGrid.selectstartcol.length;idx++) {
				if (objGrid.selectstartcol[idx] == objGrid.selectendcol[idx]) {
					var foundIdx = -1;
					for (var i=0;i<diffIdxs.length;i++) {
						if (diffIdxs[i] == idx) {
							foundIdx = i;
							break;
						}
					}
					if (foundIdx > -1) {
						for (var i=objGrid.selectstartrow[diffIdxs[foundIdx]];i<=objGrid.selectendrow[diffIdxs[foundIdx]];i++) {
							selectedCols.push(objGrid.selectstartcol[idx]);
						}
					} else {
						selectedCols.push(objGrid.selectstartcol[idx]);
						endcol = objGrid.selectstartcol[idx];
					}
				} else {
					selectedCols.push(objGrid.selectstartcol[idx]);
					selectedCols.push(objGrid.selectendcol[idx]);
				}
			}
		}
	} else {
		if( objGrid.selecttype == "row" || objGrid.selecttype == "multirow"){
			startcol = 0;
			endcol = objGrid.getCellCount("body")-1;
		} else {
			startcol = nexacro.toNumber(objGrid.selectstartcol);
			endcol   = nexacro.toNumber(objGrid.selectendcol);
		}
		
		for (var i = startrow; i <= endrow; i++) {
			for (var j = startcol; j <= endcol; j++) {
				selectedRows.push(i);
				selectedCols.push(j);
			}
		}
	}
	
	if (startrow == endrow && startcol == endcol) return null;
	
	if (selectedRows.length != selectedCols.length) {
		trace("selected Rows and Cols has been miss-calculation!");
		return null;
	}

	//trace("selectedRows=" + selectedRows+"\r\nselectedCols=" + selectedCols);
	
	for (var idx = 0;idx<selectedRows.length;idx++) {
		var rowIdx = selectedRows[idx];
		var colIdx = selectedCols[idx];
		/* Finding duplicated row and cols in indexArray and skipping from calculation */
		var duplicated = false;
		if (idx > 0) {
			for (var prevIdx=idx-1;prevIdx>=0;prevIdx--) {
				var prevRowIdx = selectedRows[prevIdx];
				var prevColIdx = selectedCols[prevIdx];
				if (!this.gfnIsNull(prevRowIdx) && !this.gfnIsNull(prevColIdx) && (prevRowIdx == rowIdx && prevColIdx == colIdx)) {
					duplicated=true;
				}
			}
			if (duplicated) continue;
		}
		/* Finding ends */
		var value = objGrid.getCellValue(rowIdx,colIdx);
//		var value = objGrid.getCellPropertyValue(rowIdx, colIdx, "text");
		if (!this.gfnIsNull(value)) {
			//trace("Getting grid cellValue["+rowIdx+"]["+colIdx+"] = " + value);
			sumData += nexacro.toNumber(value);
		}
	}

	copyData = nexacro.round(nexacro.toNumber(sumData), 1).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');

	if (copyData === undefined || copyData === null || copyData == "NaN") {
		return null;
	}
	var sBrowser = system.navigatorname;
	//copy
	if( sBrowser == "nexacro" || sBrowser == "IE"){
		system.clearClipboard();
		system.setClipboard("CF_TEXT",copyData);
	}else {
		var ta = this._createTextarea(copyData);
		this.tragetGrid = objGrid;
		this.tragetGrid["ta"] = ta;
		e.stopPropagation();
	}
	var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};

	return copyData;
};