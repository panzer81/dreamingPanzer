/**
*  @MenuPath    lfLibrary
*  @FileName 	UserEvent.js
*  @Creator 	comchief
*  @CreateDate 	2018.11.23
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2018.10.12     	comchief 	            	최초 생성 
*******************************************************************************
*/

nexacro.Component.prototype.addUserEventHandler = function(eventid, funcobj, target)
{
	if (!eventid instanceof String) {
		trace('eventid is not string: ' + eventid); return;
	}	
	if (!funcobj instanceof Function) {
		trace('funcobj is not function: ' + eventid); return;
	}
	this.__USER_EVENT_HANDLER__ = this.__USER_EVENT_HANDLER__ || {};
	this.__USER_EVENT_HANDLER__[eventid] = this.__USER_EVENT_HANDLER__[eventid] || [];
	this.__USER_EVENT_HANDLER__[eventid].push(funcobj.bind(target || this));
};

nexacro.Component.prototype.removeUserEventHandler = function(eventid, funcobj)
{
	switch(arguments.length) {
	case 0:
		this.__USER_EVENT_HANDLER__ = {};
		break;
	case 1:
		this.__USER_EVENT_HANDLER__[eventid] = [];
		break;
	default:
		var handlers = this.__USER_EVENT_HANDLER__[eventid] || [];
		for (var i=handlers.length-1; i >= 0; i--) {
			if (handlers[i] === funcobj) {
				handlers.splice(i, 1);
			}
		}
		break;
	}
};

nexacro.Component.prototype.dispatchUserEvent = nexacro.Component.prototype.fireUserEvent = function(eventid, target, event)
{
	this.__USER_EVENT_HANDLER__ = this.__USER_EVENT_HANDLER__ || {};
	var handlers = this.__USER_EVENT_HANDLER__[eventid] || [];
	for (var i=0; i < handlers.length; i++) {
		handlers[i](target, event);
	}
};
