/**
*  @MenuPath    lfLibrary
*  @FileName 	Frame.js
*  @Creator 	comchief
*  @CreateDate 	2018.10.12
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2018.10.12     	comchief 	            	최초 생성 
*******************************************************************************
*/

var pForm  = nexacro.Form.prototype;

/**
* @class frame open <br>
* @param {Object} obj - form
* @return N/A
* @example 
* this.gfnFormOnLoad(this);
*/
pForm.gfnFormOnLoad = function(objForm)
{
	var arrComp = objForm.components;
	var nLength = arrComp.length;

	for (var i=0; i<nLength; i++)
	{
		if (arrComp[i] instanceof nexacro.Div)
		{
			// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
			if (this.gfnIsNull(arrComp[i].url)) 
			{
				this.gfnFormOnLoad(arrComp[i].form);
			}
		}
		else if (arrComp[i] instanceof nexacro.Tab)
		{
			var nPages = arrComp[i].tabpages.length;
			
			for (var j=0; j<nPages;j++)
			{	
				// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
				if (this.gfnIsNull(arrComp[i].tabpages[j].url)) 
				{
					this.gfnFormOnLoad(arrComp[i].tabpages[j].form);
				}
			}
		}
		else
		{
			if (arrComp[i] instanceof nexacro.Grid) 
			{
				this.gfnSetGrid(arrComp[i]);
			}
			
			if (arrComp[i] instanceof nexacro.Edit)	
			{
				this._gfnSetEditMsClear(arrComp[i]);
			}
			
			if (arrComp[i] instanceof nexacro.Calendar)
			{
				// 월달력 Popup Div 호출 이벤트 추가
				if (arrComp[i].uCalType == "MM") 
				{
					arrComp[i].addEventHandler("ondropdown", this.gfnCalMMOndropdown, this);
				}
			}
		}
	}
};

/**
 * @class left메뉴 클릭시 해당화면 호출함수 <br>
 * @param {Object} oObj 
 * @return N/A
 * @example 
 */
pForm.gfnCall = function(oObj)
{	
	if (!this.gfnIsNull(oObj) && typeof(oObj) !=  "object") 
	{
		return;	
	}
	
	var objApp  = nexacro.getApplication();
	var gdsOpen = objApp.gdsOpenMenu;				//열린 	  dataset	
	var ds      = oObj.ds;							//넘어온 dataset
	var nRow    = oObj.nRow;						//선택된 현재 row
	var oArgs 	= oObj.oArgs;   					//넘어온 arguments
	var sMenuId;

	if (!this.gfnIsNull(oObj.sMenuId))
	{
		sMenuId = oObj.sMenuId;
	}
	else
	{
		sMenuId = ds.getColumn(nRow, objApp.gvMenuColumns.menuId);
	}
	
	var winid = gdsOpen.lookup(objApp.gvMenuColumns.menuId, sMenuId, objApp.gvMenuColumns.winId);

	if (!this.gfnIsNull(winid))
	{
		if (objApp.gvMdiFrame.form.isActiveFrame(winid, oArgs) == true)
		{
			objApp.gvMdiFrame.form.fnMoveTab(winid);
			return;
		}
	}

	//열린메뉴 체크( application.gvMax = 8)	
	if (objApp.gvMax < gdsOpen.getRowCount() )
	{
		alert(objApp.gvMax +"개 초과하여 화면을 열수 없습니다");
		return false;
	}
	
	// 메뉴이력 남기기. 2019.1.2. gagamel
	this.gfnCreateMenuHistory(sMenuId);
	
	this.gfnNewMdi(sMenuId, nRow, oArgs);
};

/**
 * @class 메뉴이력을 남기기<br>
 * @param {String} sMenuId - menuId
 * @return N/A
 */
pForm.gfnCreateMenuHistory = function(sMenuId)
{
	var strSvcId    = "save";
	var strSvcUrl   = "system/menuUseHistory/create";
	var inData      = "";
	var outData     = "";
	var strArg      = "MENU_ID='" + sMenuId + "'";
	var callBackFnc = "";
	
	this.gfnTransaction(strSvcId,		// transaction을 구분하기 위한 svc id값
						strSvcUrl,		// trabsaction을 요청할 주소
						inData, 		// 입력값으로 보낼 dataset id , a=b형태로 실제이름과 입력이름을 매칭
						outData, 		// 처리결과값으로 받을 dataset id, a=b형태로 실제이름과 입력이름을 매칭
						strArg, 		// 입력값로 보낼 arguments, strFormData="20120607"
						callBackFnc,	// 통신완료 후 Event
						false);
};

/**
 * @class gdsOpenMenu의 해당 Row의 정보를 기준으로 신규 윈도우 화면을 생성하고 open 시킴 <br>
 * @param {String} sMenuId - menuId
 * @param {Number} nRow - gdsOpenMenu의rowpostion
 * @param {Object} oArgs - arguments
 * @return N/A
 */
pForm.gfnNewMdi = function(sMenuId, nRow, oArgs)
{	
	var objApp   = nexacro.getApplication();
	var gdsOpen  = objApp.gdsOpenMenu;		//열린 dataset
	var gdsMenu  = objApp.gdsMenuList;
	var winid    = "WIN" + sMenuId + "_" + gdsOpen.getRowCount() + "_" + parseInt(Math.random() * 1000);		
	var sPageUrl = gdsMenu.lookupAs(objApp.gvMenuColumns.menuId, sMenuId, objApp.gvMenuColumns.pageUrl);
	var sGroupId = gdsMenu.lookupAs(objApp.gvMenuColumns.menuId, sMenuId, objApp.gvMenuColumns.groupId);
	var sNavigation = gdsMenu.lookupAs(objApp.gvMenuColumns.menuId, sMenuId, objApp.gvMenuColumns.navigation);

	var sColumn  = objApp.gvMenuColumns.menuNm;

	var sMenuNm  = gdsMenu.lookupAs(objApp.gvMenuColumns.menuId, sMenuId, sColumn);

	if (this.gfnIsNull(sPageUrl)) 
	{
		return;		//pageURl 이 없으면 return
	}
	
	this.gfnSetOpenMenuDs(winid, sMenuId, sMenuNm, sPageUrl, sGroupId);	// 열린메뉴 화면 삽입

	var objNewWin = new ChildFrame;
	objNewWin.init(winid, 0, 0, objApp.gvFrameSet.getOffsetWidth() - 0, objApp.gvFrameSet.getOffsetHeight() - 0);
	objApp.gvFrameSet.addChild(winid, objNewWin);

	//objNewWin.set_tooltiptext(winid);
	objNewWin.arguments = [];
	objNewWin.set_dragmovetype("all");
	objNewWin.set_showtitlebar(false);
	objNewWin.set_resizable(true);
	objNewWin.set_titlebarheight(30);
	objNewWin.set_openstatus("maximize");
	objNewWin.set_titletext(sMenuNm);
	objNewWin.set_showcascadetitletext(false);
	objNewWin.arguments["WIN_ID"] = winid;
	objNewWin.arguments["MENU_ID"] = sMenuId;
	objNewWin.arguments["MENU_NM"] = sMenuNm;
	objNewWin.arguments["MENU_URL"] = sPageUrl;
	objNewWin.arguments["NAVIGATION"] = sNavigation;
	objNewWin.arguments["OARGS"] = oArgs;
	objNewWin.set_formurl("FrameBase::frmWork.xfdl");

	objApp.gvMdiFrame.form.fnAddTab(winid, sMenuNm);   //mdi tab button add	
	objApp.gvMdiFrame.form.isActiveFrame(winid);

	objNewWin.show();	
};

/**
 * @class 열린화면 데이터셋에 추가 <br>
 * @param {String} winid
 * @param {String} menuId
 * @param {String} strTitle
 * @param {String} spageUrl
 * @param {String} sGroupId
 * @return N/A
 */
pForm.gfnSetOpenMenuDs = function(winid, menuid, strTitle, spageUrl, sGroupId)
{
	var objApp  = nexacro.getApplication();
	var gdsOpen = objApp.gdsOpenMenu ;  //열린 dataset
	var nRow = gdsOpen.addRow();
	gdsOpen.setColumn(nRow, objApp.gvMenuColumns.winId, winid);
	gdsOpen.setColumn(nRow, objApp.gvMenuColumns.menuId, menuid);
	gdsOpen.setColumn(nRow, objApp.gvMenuColumns.title, strTitle);	
	gdsOpen.setColumn(nRow, objApp.gvMenuColumns.groupId, sGroupId);
	gdsOpen.setColumn(nRow, "URL", spageUrl);
};

/**
 * @class 해당화면 데이터셋에 추가 <br>
 * @param {String} 	sName : winKey, menuId, menuNm, pageUrl, oArgs
 * @return String
 */
pForm.gfnGetServerUrl = function()
{
	var urlPath = "";

	var objEnv = nexacro.getEnvironment();
	urlPath = objEnv.services["Service"].url;
	
	return urlPath;
};

/**
 * @class 해당화면 데이터셋에 추가 <br>
 * @param {String} 	sName : winKey, menuId, menuNm, pageUrl, oArgs
 * @return String
 */
pForm.gfnGetArgument = function(sName)
{
	return this.getOwnerFrame().arguments[sName];
};

/**
 * @class 팝업오픈
 * @param {String} sPopupId	- 팝업ID
 * @param {String} sUrl	 - 팝업URL
 * @param {String} [oArg] - 전달값
 * @param {String} [sPopupCallback] - 팝업콜백
 * @param {Object} [oOption] - 팝업옵션 <br>
 *	oOption.top : 상단 좌표 <br>
 *	oOption.left : 좌측 좌표 <br>
 *	oOption.width : 넓이 <br>
 *	oOption.height : 높이 <br>
 *	oOption.popuptype : 팝업종류(modal:showModal, modeless:application.open, modalsync:showModalSync, modalwindow:showModalWindow) <br>
 *	oOption.layered : 투명 윈도우 <br>
 *	oOption.opacity : 투명도 <br>
 *	oOption.autosize : autosize <br>
 *  oOption.resizable : resizable <br>
 * @return N/A
 * @example
 * this.gfnOpenPopup(this);
 */
pForm.gfnOpenPopup = function(sPopupId, sUrl, oArg, sPopupCallback, oOption)
{
    var objApp = nexacro.getApplication();
	var nLeft = -1;
	var nTop = -1;
	var nWidth = -1;
	var nHeight = -1;
	var bShowTitle = true;	
	var bShowStatus = false;	
	var sPopupType = "modal";
	var bLayered = false;
	var nOpacity = 100;
	var bAutoSize = false;
	var bResizable = false;
	var sDragMoveType = "all";
	var sTitleText = "";

	for (var key in oOption) 
	{
       if (oOption.hasOwnProperty(key)) 
	   {
            switch (key) 
			{
				case "top":				
					nTop = parseInt(oOption[key]);
					break;
				case "left":
					nLeft = parseInt(oOption[key]);
					break;
				case "width":
					nWidth = parseInt(oOption[key]);
					break;
				case "height":
					nHeight = parseInt(oOption[key]);
					break;
				case "popuptype":
					sPopupType = oOption[key];
					break;
				case "layered":
					bLayered = oOption[key];
					break;
				case "opacity":
					nOpacity =oOption[key];
					break;
				case "autosize":
					bAutoSize = oOption[key];
					break;
				case "resizable":
					bResizable = oOption[key];
					break;
				case "dragmovetype":
					sDragMoveType = oOption[key];
					break;
				case "titlebar":
					if (""+oOption[key] == "false")	bShowTitle = false;		
					break;
				case "title":					
					sTitleText = oOption[key];	
					break;					
			}	
        }
    }

	var sOpenalign = "";
	if (nLeft == -1 && nTop == -1) 
	{		
		sOpenalign = "center middle";
		if (system.navigatorname == "nexacro") 
		{
			var curX = objApp.mainframe.left;
			var curY = objApp.mainframe.top;
		}
		else
		{
			var curX = window.screenLeft;
			var curY = window.screenTop;
		}
		
        nLeft   =  curX + (objApp.mainframe.width / 2) - Math.round(nWidth / 2);
	    nTop    = curY + (objApp.mainframe.height / 2) - Math.round(nHeight / 2) ;		
		
	}
	else
	{
		nLeft   =  this.getOffsetLeft() + nLeft;
		nTop   =  this.getOffsetTop() + nTop;
	}
		
	if (nWidth == -1 || nHeight == -1)
	{
	    bAutoSize = true;
	}
	
	var objParentFrame = this.getOwnerFrame();

    if (sPopupType == "modeless")
    {
        var sOpenStyle= "showtitlebar=true showstatusbar=false showontaskbar=true showcascadetitletext=false resizable="+bResizable+" autosize="+bAutoSize+" titletext='"+sTitleText+"'";
		var arrPopFrame = nexacro.getPopupFrames();

		if (arrPopFrame[sPopupId])
		{	
			if (system.navigatorname == "nexacro")
			{
				arrPopFrame[sPopupId].setFocus();
			} 
			else
			{	
				arrPopFrame[sPopupId]._getWindowHandle().focus();
			}
		}
		else 
		{
			nexacro.open(sPopupId, sUrl, objParentFrame, oArg, sOpenStyle, nLeft, nTop, nWidth, nHeight, this);
		}
    }
	else if (sPopupType == "modalsync")
    {
		newChild = new nexacro.ChildFrame;
		newChild.init(sPopupId, nLeft, nTop, nWidth, nHeight, null, null, sUrl);
		
		newChild.set_dragmovetype(sDragMoveType);
		newChild.set_showcascadetitletext(false);
		newChild.set_showtitlebar(bShowTitle);    //titlebar는 안보임
		newChild.set_autosize(bAutoSize);	
		newChild.set_resizable(bResizable);    //resizable 안됨
		newChild.set_titlebarheight(30);
		if (!this.gfnIsNull(sTitleText)) 
		{
			newChild.set_titletext(sTitleText);
		}
		newChild.set_showstatusbar(bShowStatus);    //statusbar는 안보임
		newChild.set_openalign(sOpenalign);
		newChild.set_layered(bLayered);
		newChild.set_overlaycolor("RGBA(0, 0, 0, 0.2)");
		var rtn = system.showModalSync(newChild, objParentFrame, oArg);	
	}
	else if (sPopupType == "modalwindow")
    {
		newChild = new nexacro.ChildFrame;
		newChild.init(sPopupId, nLeft, nTop, nWidth, nHeight, null, null, sUrl);
		
		newChild.set_dragmovetype(sDragMoveType);
		newChild.set_showcascadetitletext(false);
		newChild.set_showtitlebar(bShowTitle);    //titlebar는 안보임
		newChild.set_autosize(bAutoSize);	
		newChild.set_resizable(bResizable);    //resizable 안됨
		newChild.set_titlebarheight(30);
		if (!this.gfnIsNull(sTitleText))
		{
			newChild.set_titletext(sTitleText);
		}
		newChild.set_showstatusbar(bShowStatus);    //statusbar는 안보임
		newChild.set_openalign(sOpenalign);
		newChild.set_layered(bLayered);
		newChild.set_overlaycolor("RGBA(0, 0, 0, 0.2)");
		var rtn = system.showModalWindow(newChild, sPopupId, objParentFrame, oArg);		
        return rtn;
	}	
    else
    {
		newChild = new nexacro.ChildFrame;
		newChild.init(sPopupId, nLeft+100, nTop, nWidth, nHeight, null, null, sUrl);
		
		newChild.set_dragmovetype(sDragMoveType);
		newChild.set_showcascadetitletext(false);
		newChild.set_showtitlebar(bShowTitle);    //titlebar는 안보임
		newChild.set_autosize(bAutoSize);	
		newChild.set_resizable(bResizable);    //resizable 안됨
		newChild.set_titlebarheight(30);
		if (!this.gfnIsNull(sTitleText)) 
		{
			newChild.set_titletext(sTitleText);
		}
		newChild.set_showstatusbar(bShowStatus);    //statusbar는 안보임
		newChild.set_openalign(sOpenalign);
		newChild.set_layered(bLayered);
		newChild.set_overlaycolor("RGBA(0, 0, 0, 0.2)");
		newChild.showModal(objParentFrame, oArg, this, this[sPopupCallback]);
    }
};
