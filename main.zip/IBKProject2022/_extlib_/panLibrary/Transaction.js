/**
*  @MenuPath    lfLibrary
*  @FileName 	Transaction.js
*  @Creator 	comchief
*  @CreateDate 	2018.10.12
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2018.10.12     	comchief 	            	최초 생성 
*******************************************************************************
*/

var pForm  = nexacro.Form.prototype;

pForm.fvSessionId = "";					// JSESSIONID
pForm.fvOldSessionId = "";				// JSESSIONID
pForm.fvIsLogin = "";					// Login 여부

/**
 * @class 서비스 호출 공통함수 <br>
 * 
 * @param {String} strSvcId - 서비스 ID
 * @param {String} strSvcUrl - 서비스 호출 URL 
 * @param {String} [inData]	- input Dataset list ("입력ID=DataSetID" 형식으로 설정하며 빈칸으로 구분하여 다중입력이 가능)
 * @param {String} [outData] - output Dataset list ("DataSetID=출력ID" 형식으로 설정하며 빈칸으로 구분하여 다중입력이 가능)
 * @param {String} [strArg]	- 서비스 호출시 Agrgument ("ArgumentID=value" 형식으로 설정하며 빈칸으로 구분하여 다중입력이 가능)
 * @param {String} [callBackFnc] - 콜백 함수명
 * @param {Boolean} [isAsync] - 비동기통신 여부 
 * @param {Array} [oOption] - Option (grid[string] : Total Count 를 위한 Grid 명, target[string] : Grid, Static 이 위치한 곳, message[boolean] : Message 호출 여부) 
 * @return 
 * @example
 * var strSvcUrl = "transactionSaveTest.do";
 * var inData    = "dsList=dsList:U";
 * var outData   = "dsList=dsList";
 * var strArg    = "";
 * this.gfnTransaction("save", strSvcUrl, inData, outData, strArg, "fnCallback", true);
 */ 
pForm.gfnTransaction = function(strSvcId, strSvcUrl, inData, outData, strArg, callBackFnc, isAsync, oOption)
{
	if (this.gfnIsNull(strSvcId) || this.gfnIsNull(strSvcUrl))
	{
		this.gfnMessage("Error : gfnTransaction() 함수의 필수인자값이 부족합니다.", "A");
		return false;
	}
	
	// fnCallback 함수 기본값 설정
	if (this.gfnIsNull(callBackFnc)) 
	{
		callBackFnc = "fnCallback";
	}
	
	var objDate = new Date();
	var nStartTime = objDate.getTime();
    var sStartDate = objDate.getYear()
						+"-"+String(objDate.getMonth()).padLeft(2, '0')
						+"-"+String(objDate.getDate()).padLeft(2, '0')
						+" "+String(objDate.getHours()).padLeft(2, '0')
						+":"+String(objDate.getMinutes()).padLeft(2, '0')
						+":"+String(objDate.getSeconds()).padLeft(2, '0')
						+" "+objDate.getMilliseconds();

	// Async
	if ((isAsync != true) && (isAsync != false))
	{
		isAsync = true;	
	}
	
	// 1. callback에서 처리할 서비스 정보 저장
	var objSvcID;
	if (this.gfnIsNull(oOption))
	{
		objSvcID = { 
			svcId     : strSvcId,
			svcUrl    : strSvcUrl,
			callback  : callBackFnc,
			isAsync   : isAsync,
			startDate : sStartDate,
			startTime : nStartTime};
	}
	else
	{
		objSvcID = { 
			svcId     : strSvcId,
			svcUrl    : strSvcUrl,
			callback  : callBackFnc,
			isAsync   : isAsync,
			startDate : sStartDate,
			startTime : nStartTime,
			sGrid     : oOption.grid,
			sTarget   : oOption.target,
			bMessage  : oOption.message};
	}
	
	// 2. strServiceUrl
	var strServiceUrl = "Service::" + strSvcUrl;
	
	// 3. strArg
	var strArguments = "";
	if (this.gfnIsNull(strArg)) 
	{
		strArguments = "";
	}
	else 
	{ 
		strArguments = strArg;
	}

	// 개발시에는 xml, 개발서버/운영서버는 SSV로 통신
	var nDataType;	
	if (nexacro.getEnvironmentVariable("evRunMode") == "2") 
	{
		nDataType = 2;
	}
	else 
	{
		nDataType = 0;
	}
	
	this.transaction( JSON.stringify(objSvcID)  //1.svcID
					, strServiceUrl             //2.strServiceUrl
					, inData                    //3.inDataSet
					, outData                   //4.outDataSet
					, strArguments              //5.arguments
					, "gfnCallback"				//6.strCallbackFunc
					, isAsync                   //7.bAsync
					, nDataType                 //8.nDataType : 0(XML 타입), 1((Binary 타입),  2(SSV 타입) --> HTML5에서는 Binary 타입은 지원안함
					, false);                   //9.bCompress ( default : false ) 
};

/**
 * @class 공통 Callback 함수 <br>
 * 이 함수가 먼저 수행되고 사용자지정Callback함수가 수행된다.
 * @param {String} svcID - 서비스 ID
 * @param {Number} errorCode - 에러코드(정상 0, 에러 음수값)
 * @param {String} [errorMsg] - 에러메시지
 * @return N/A
 */
pForm.gfnCallback = function(svcID, errorCode, errorMsg)
{
	var objSvcID = JSON.parse(svcID);

	// 에러 공통 처리
	if (errorCode < 0)
	{
		if ((objSvcID.svcId != "getsessionid" && objSvcID.svcId != "getislogin" && objSvcID.callback != "NO_ERR_MSG") || (objSvcID.callback == "NO_ERR_MSG" && errorCode != -1))
		{
			var sMsg = "[" + objSvcID.svcId + " : " + errorCode + "] " + errorMsg;
			var sType = "A";
            
            // 세션 타임아웃 되었을 경우만 쿠키세션 제거 및 로그인 페이지 이동하도록
            if (errorCode === -1 && errorMsg.indexOf("로그인 상태가 아닙니다.") > -1)
                this.gfnMessage(sMsg, sType, "fnErrorCallback");
            else
                this.gfnMessage(sMsg, sType);
		}		
	}
	else // 성공 공통 처리
	{
		if (!this.gfnIsNull(objSvcID.bMessage))
		{
			if (objSvcID.bMessage)
			{
				var sMsg = errorMsg;
				var sType = "A";
				this.gfnMessage(sMsg, sType);
			}
		}
	}

	// 서비스 실행결과 출력
	var sStartDate = objSvcID.startDate;
	var nStartTime = objSvcID.startTime;
	
	var objDate = new Date();
	var sEndDate = objDate.getYear()
					+"-"+String(objDate.getMonth()).padLeft(2, '0')
					+"-"+String(objDate.getDate()).padLeft(2, '0')
					+" "+String(objDate.getHours()).padLeft(2, '0')
					+":"+String(objDate.getMinutes()).padLeft(2, '0')
					+":"+String(objDate.getSeconds()).padLeft(2, '0')
					+" "+objDate.getMilliseconds();
	var nElapseTime = (objDate.getTime() - nStartTime)/1000;
	
	var sMsg = "";
	if (errorCode == 0)
	{
		sMsg = "gfnCallback : svcID>>"+objSvcID.svcId+ ",  svcUrl>>"+objSvcID.svcUrl+ ",  errorCode>>"+errorCode + ", errorMsg>>"+errorMsg + ", isAsync>>" + objSvcID.isAsync + ", sStartDate>>" + sStartDate + ", sEndDate>>"+sEndDate + ", nElapseTime>>"+nElapseTime;
	}
	else 
	{
		sMsg = "gfnCallback : svcID>>"+objSvcID.svcId+ ",  svcUrl>>"+objSvcID.svcUrl+ ",  errorCode>>"+errorCode + ", isAsync>>" + objSvcID.isAsync + ", sStartDate>>" + sStartDate + ", sEndDate>>"+sEndDate + ", nElapseTime>>"+nElapseTime;
		sMsg += "\n==================== errorMsg =======================\n"+errorMsg+"\n==================================================";
	}
	
	// 화면의 Grid 에 조회된 건수 확인하기
	if (!this.gfnIsNull(objSvcID.sGrid))
	{
		var objTarget;

		if (this.gfnIsNull(objSvcID.sTarget))
		{
			objTarget = this;
		}
		else
		{
			objTarget = eval(objSvcID.sTarget);
		}

		var objStatic = this.gfnFindObj(objTarget, "sta_" + objSvcID.sGrid); // Static 의 명칭은 sta_GridName 으로 명명한다.
		var objGrid = this.gfnFindObj(objTarget, objSvcID.sGrid);
		objGrid.set_nodatatext("데이터가 존재하지 않습니다.");
		var objDataset = objGrid.getBindDataset();
		var nRowCnt = objDataset.rowcount;
		var sStaticVal = "(총 " + this.gfnAppendComma(nRowCnt) + "건)";
		// decoration 을 주시려면 Static 의 usedecorate = true 로 해주셔야 합니다. (help 를 보시면 사용법이 있습니다.)
//		var sStaticVal = "(<b v='true'>총</b> <fc v='red'>" + this.gfnAppendComma(nRowCnt) + "</fc><b v='true'>건</b>)"; 
		if (!this.gfnIsNull(objStatic))
		{
			objStatic.set_text(sStaticVal);
		}
	}

	// 화면의 callBack 함수 실행
	if (!this.gfnIsNull(objSvcID.svcId))
	{
		// form에 callback 함수가 있을때
		if (this[objSvcID.callback]) 
		{
			this.lookupFunc(objSvcID.callback).call(objSvcID.svcId, errorCode, errorMsg);
		}
	}
};

/**
 * @class 콤보에 활용할 정보를 조회
 * @param {Object} obj - Combo
 * @param {String} sSvcUrl - Service Url
 * @param {String} sArg - Service Argument
 * @param {Array} oOption - bCodeDisplay (Code + NAME 여부), sOption (All_Title), sSelCode (초기 선택 코드값)
 * @param isAsync - 비동기(true), 동기(false) 또는 미입력시 동기
 * @return
 */
pForm.gfnGetCombo = function (obj, sSvcUrl, sArg, sOption, isAsync)
{
	var objApp = nexacro.getApplication();
	var form;
	
	if (this.gfnIsNull(sSvcUrl))
	{
		return;
	}
	
	if (this.gfnIsNull(isAsync))
	{
		isAsync = false;
	}

	while (this.gfnTypeOf(form) != "Form")
	{
		form = obj.parent;
	}
	
	this.Combo = obj;
	this.Option = sOption;
	
	var strSvcId    = "getcombo";
	var strSvcUrl   = sSvcUrl;
	var inData      = "";
	var outData     = obj.getInnerDataset().name + "=dsCodeList";
	var strArg      = sArg;
	var callBackFnc = "gfnComboCallback";
	
	this.gfnTransaction(strSvcId ,		// transaction을 구분하기 위한 svc id값
						strSvcUrl , 	// trabsaction을 요청할 주소
						inData , 		// 입력값으로 보낼 dataset id , a=b형태로 실제이름과 입력이름을 매칭
						outData , 		// 처리결과값으로 받을 dataset id, a=b형태로 실제이름과 입력이름을 매칭
						strArg, 		// 입력값로 보낼 arguments, strFormData="20120607"
						callBackFnc, 	// 통신완료 후 Event
						isAsync);			// aSync 여부
};	

/**
 * Callback
 */
pForm.gfnComboCallback = function(svcID, errorCode, errorMsg)
{
	if (svcID == "getcombo")
	{
		if (this.gfnIsNull(this.Option))
		{
			return;
		}

		var obj = this.Combo.getInnerDataset();
		
		var bCodeDisplay = this.gfnNvl(this.Option.bCodeDisplay, true);
		
		if (bCodeDisplay)
		{
			var nCnt = obj.rowcount;
			obj.set_enableevent(false);
			for (var i=0; i <= nCnt-1; i++)
			{
				var sValue = obj.getColumn(i, "CODE_NM");
				if (!this.gfnIsNull(obj.getColumn(i, "CODE"))) {
					sValue = "[" + obj.getColumn(i, "CODE") + "] " + obj.getColumn(i, "CODE_NM");
				}
				obj.setColumn(i, "CODE_NM", sValue);
			}
			obj.set_enableevent(true);
		}
		
		if (!this.gfnIsNull(this.Option.sOption))
		{
			obj.insertRow(0);
			obj.setColumn(0, "CODE", "");
			obj.setColumn(0, "CODE_NM", this.Option.sOption);
			this.Combo.set_index(0);
		}
		
		if (!this.gfnIsNull(this.Option.sSelCode))
		{
			var nRow = obj.findRow("CODE", this.Option.sSelCode);
			if (nRow >= 0)
			{
				this.Combo.set_value(this.Option.sSelCode);
			}
		}
	}
};

/**
 * errorCallback(트랜잭션 오류발생시 처리)
 */
pForm.fnErrorCallback = function (msgid, msgval)
{
	if (msgval)
    {
        nexacro.setPrivateProfile("JSESSIONID", "");
        
        if (system.navigatorname == "nexacro")		// Runtime
        {
            nexacro.getApplication().gvTopFrame.form.fnLogout();
        } else //   HTML5
        {
            nexacro.getApplication().gvTopFrame.form.fnLogout("web");
        }
    }
};

/**
 * 로그인 상태 확인
 */
pForm.gfnCheckSession = function()
{
	var strSvcId    = "getsessionid";
	var strSvcUrl   = "system/sessionid";
	var inData      = "";
	var outData     = "";
	var strArg      = "";
	var callBackFnc = "fnCallback";
	var async		= true;
	
// 	if (system.navigatorname == "nexacro") 
// 	{
// 		strSvcId    = "getislogin";
// 		strSvcUrl   = "system/isLogin";
// 	}

	this.gfnTransaction(strSvcId ,		// transaction을 구분하기 위한 svc id값
						strSvcUrl , 	// trabsaction을 요청할 주소
						inData , 		// 입력값으로 보낼 dataset id , a=b형태로 실제이름과 입력이름을 매칭
						outData , 		// 처리결과값으로 받을 dataset id, a=b형태로 실제이름과 입력이름을 매칭
						strArg, 		// 입력값로 보낼 arguments, strFormData="20120607"
						callBackFnc,	// 통신완료 후 Event
						async);			// aSync 통신여부	
};
