(function()
{
	return function()
	{
		nexacro._setCSSMaps(
		{
            "Edit" :
            			{
            				"self" :
            				{
            					"enabled" :
            					{
            						"border" : nexacro.BorderObject("1px solid #cccccc")
            					}
            				}
            			},
            			"Combo" :
            			{
            				"self" :
            				{
            					"enabled" :
            					{
            						"border" : nexacro.BorderObject("1px solid #cccccc")
            					}
            				}
            			},
            			"Calendar" :
            			{
            				"self" :
            				{
            					"enabled" :
            					{
            						"border" : nexacro.BorderObject("1px solid #cccccc")
            					}
            				}
            			},
            			"TextArea" :
            			{
            				"self" :
            				{
            					"enabled" :
            					{
            						"border" : nexacro.BorderObject("1px solid #cccccc")
            					}
            				}
            			},
            			"Div" :
            			{
            				"self" :
            				{
            					"enabled" :
            					{
            						"border" : nexacro.BorderObject("1px solid #cccccc")
            					}
            				}
            			},
            			"Static" :
            			{
            				"class" :
            				[
            					{
            						"static_WF_year" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("bold 17px \"Arial\"")
            								}
            							}
            						}
            					},
            					{
            						"static_WF_label1" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("13px \"Arial\"")
            								},
            								"mouseover" :
            								{
            								},
            								"disabled" :
            								{
            								}
            							}
            						}
            					},
            					{
            						"static_WF_label2" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("13px \"Arial\"")
            								},
            								"mouseover" :
            								{
            								},
            								"disabled" :
            								{
            								}
            							}
            						}
            					},
            					{
            						"static_WF_label3" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("13px \"Arial\"")
            								},
            								"mouseover" :
            								{
            								},
            								"disabled" :
            								{
            								}
            							}
            						}
            					},
            					{
            						"static_WF_label4" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("13px \"Arial\"")
            								},
            								"mouseover" :
            								{
            								},
            								"disabled" :
            								{
            								}
            							}
            						}
            					},
            					{
            						"static_WF_label5" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("13px \"Arial\"")
            								},
            								"mouseover" :
            								{
            								},
            								"disabled" :
            								{
            								}
            							}
            						}
            					},
            					{
            						"static_WF_title" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"font" : nexacro.FontObject("13px \"Arial\""),
            									"border" : nexacro.BorderObject("0px none")
            								}
            							}
            						}
            					}
            				]
            			},
            			"Button" :
            			{
            				"class" :
            				[
            					{
            						"btn_WF_save" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"border" : nexacro.BorderObject("1px solid #363636"),
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"mouseover" :
            								{
            									"border" : nexacro.BorderObject("1px solid #363636"),
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"pushed" :
            								{
            									"border" : nexacro.BorderObject("1px solid #363636"),
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"focused" :
            								{
            									"border" : nexacro.BorderObject("1px solid #363636"),
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"selected" :
            								{
            									"border" : nexacro.BorderObject("1px solid #363636"),
            									"color" : nexacro.ColorObject("#ffffff"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"disabled" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#777777"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								}
            							}
            						}
            					},
            					{
            						"btn_WF_cancel" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"mouseover" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"pushed" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"focused" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"selected" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"disabled" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#777777"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								}
            							}
            						}
            					},
            					{
            						"btn_WF_today" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"mouseover" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"pushed" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"focused" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"selected" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"disabled" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#777777"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								}
            							}
            						}
            					},
            					{
            						"btn_WF_new" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"mouseover" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"pushed" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"focused" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"selected" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#000000"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								},
            								"disabled" :
            								{
            									"border" : nexacro.BorderObject("1px solid #cccccc"),
            									"color" : nexacro.ColorObject("#777777"),
            									"font" : nexacro.FontObject("15px \"Arial\"")
            								}
            							}
            						}
            					},
            					{
            						"btn_WF_left" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-left.png')")
            								},
            								"mouseover" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-left.png')")
            								},
            								"pushed" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-left.png')")
            								},
            								"focused" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-left.png')")
            								},
            								"selected" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-left.png')")
            								},
            								"disabled" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-left.png')")
            								}
            							}
            						}
            					},
            					{
            						"btn_WF_right" :
            						{
            							"self" :
            							{
            								"enabled" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-right.png')")
            								},
            								"mouseover" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-right.png')")
            								},
            								"pushed" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-right.png')")
            								},
            								"focused" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-right.png')")
            								},
            								"selected" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-right.png')")
            								},
            								"disabled" :
            								{
            									"border" : nexacro.BorderObject("0px none"),
            									"icon" : nexacro.UrlObject("url('imagerc::schedulerv3/arrow-right.png')")
            								}
            							}
            						}
            					}
            				]
            			}
		},
		{
            "includeStatusMap" : true
		}
		);
		var imgcache = nexacro._getImageCacheMaps();

	};
}
)();
