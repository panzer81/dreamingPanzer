(function()
{
	return function()
	{
		nexacro._setCSSMaps(
		{
            "spinedit" :
            			{
            				"parent" :
            				{
            					"yearspin" :
            					{
            						"parent" :
            						{
            							"head" :
            							{
            								"parent" :
            								{
            									"datepicker" :
            									{
            										"parent" :
            										{
            											"Calendar" :
            											{
            												"self" :
            												{
            													"enabled" :
            													{
            														"color" : nexacro.ColorObject("black"),
            														"font" : nexacro.FontObject("normal 10pt/normal \"Arial\"")
            													}
            												}
            											}
            										}
            									}
            								}
            							}
            						}
            					},
            					"monthspin" :
            					{
            						"parent" :
            						{
            							"head" :
            							{
            								"parent" :
            								{
            									"datepicker" :
            									{
            										"parent" :
            										{
            											"Calendar" :
            											{
            												"self" :
            												{
            													"enabled" :
            													{
            														"color" : nexacro.ColorObject("black"),
            														"font" : nexacro.FontObject("normal 10pt/normal \"Arial\"")
            													}
            												}
            											}
            										}
            									}
            								}
            							}
            						}
            					}
            				}
            			},
            			"head" :
            			{
            				"parent" :
            				{
            					"datepicker" :
            					{
            						"parent" :
            						{
            							"Calendar" :
            							{
            								"self" :
            								{
            									"enabled" :
            									{
            										"border" : nexacro.BorderObject("1px #edf2f9")
            									}
            								}
            							}
            						}
            					}
            				}
            			},
            			"body" :
            			{
            				"parent" :
            				{
            					"datepicker" :
            					{
            						"parent" :
            						{
            							"Calendar" :
            							{
            								"self" :
            								{
            									"enabled" :
            									{
            										"border" : nexacro.BorderObject("1px #edf2f9"),
            										"padding" : nexacro.PaddingObject("0px")
            									}
            								}
            							}
            						}
            					}
            				}
            			},
            			"weekitem" :
            			{
            				"parent" :
            				{
            					"body" :
            					{
            						"parent" :
            						{
            							"datepicker" :
            							{
            								"parent" :
            								{
            									"Calendar" :
            									{
            										"self" :
            										{
            											"enabled" :
            											{
            												"color" : nexacro.ColorObject("black"),
            												"font" : nexacro.FontObject("normal 12pt/normal \"Arial\"")
            											},
            											"saturday" :
            											{
            												"color" : nexacro.ColorObject("blue"),
            												"font" : nexacro.FontObject("normal 12pt/normal \"Arial\"")
            											},
            											"sunday" :
            											{
            												"color" : nexacro.ColorObject("red"),
            												"font" : nexacro.FontObject("normal 12pt/normal \"Arial\"")
            											}
            										}
            									}
            								}
            							}
            						}
            					}
            				}
            			},
            			"dayitem" :
            			{
            				"parent" :
            				{
            					"body" :
            					{
            						"parent" :
            						{
            							"datepicker" :
            							{
            								"parent" :
            								{
            									"Calendar" :
            									{
            										"self" :
            										{
            											"enabled" :
            											{
            												"font" : nexacro.FontObject("normal 10pt/normal \"Arial\""),
            												"padding" : nexacro.PaddingObject("10px 0px 0px 15px")
            											},
            											"day" :
            											{
            												"font" : nexacro.FontObject("normal 10pt/normal \"Arial\"")
            											},
            											"sunday" :
            											{
            												"font" : nexacro.FontObject("normal 10pt/normal \"Arial\"")
            											},
            											"saturday" :
            											{
            												"font" : nexacro.FontObject("normal 10pt/normal \"Arial\"")
            											},
            											"selected" :
            											{
            												"color" : nexacro.ColorObject("black"),
            												"font" : nexacro.FontObject("normal 10pt/normal \"Arial\"")
            											},
            											"trailingday" :
            											{
            												"color" : nexacro.ColorObject("black"),
            												"font" : nexacro.FontObject("normal 10pt/normal \"Arial\"")
            											},
            											"focused" :
            											{
            												"color" : nexacro.ColorObject("black"),
            												"font" : nexacro.FontObject("normal 10pt/normal \"Arial\"")
            											},
            											"mouseover" :
            											{
            												"color" : nexacro.ColorObject("black"),
            												"font" : nexacro.FontObject("normal 10pt/normal \"Arial\"")
            											},
            											"today" :
            											{
            												"color" : nexacro.ColorObject("black"),
            												"font" : nexacro.FontObject("normal 10pt/normal \"Arial\"")
            											}
            										}
            									}
            								}
            							}
            						}
            					}
            				}
            			}
		},
		{
            "includeStatusMap" : true
		}
		);
		var imgcache = nexacro._getImageCacheMaps();

	};
}
)();
