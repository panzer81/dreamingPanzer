package com.demo;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.panframework.web.ui.nexacro.PanNexacroData;
import com.panframework.web.ui.nexacro.annotation.PanNexacroParam;

@Controller
//@RequestMapping("/demo")
public class DemoController {
    
    private static final Logger log = LoggerFactory.getLogger(DemoController.class);
    
    /**
     * transactionSelectTest
     * @param nexaData
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/transactionSelectTest")
    public ModelAndView transactionSelectTest(@PanNexacroParam PanNexacroData nexaData) throws Exception{
        
        log.debug("transactionSelectTest ..."+nexaData.getDataSetParameterMap("dsSearch"));
        
        nexaData.of("0", "SUCCESS");
        ModelAndView mav = new ModelAndView("nexacroView");
        mav.addObject(nexaData);
        return mav;
        
    }

    /**
     * transactionSaveTest
     * @param nexaData
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/transactionSaveTest")
    public ModelAndView transactionSaveTest(@PanNexacroParam PanNexacroData nexaData) throws Exception{
        
        log.debug("transactionSelectTest ..."+nexaData.getDataSetParameterMapList("dsList"));
        
        nexaData.of("0", "SUCCESS");
        ModelAndView mav = new ModelAndView("nexacroView");
        mav.addObject(nexaData);
        return mav;
        
    }
    
}
