package com.demo;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.panframework.web.ui.nexacro.resolver.PanNexacroArgumentResolver;
import com.panframework.web.ui.nexacro.view.PanNexacroSsvView;
import com.panframework.web.ui.nexacro.view.PanNexacroView;

/**
 * Web MVC Configuration
 * @author 이승환
 * @since 2022. 12. 04
 */
@Configuration
@EnableWebMvc
public class WebMvcConfig extends WebMvcConfigurerAdapter {

    
    /**
     * Nexacro Argument Resolver Bean 등록
     * @return
     */
    @Bean
    public PanNexacroArgumentResolver nexacroArgumentResolver() {
        PanNexacroArgumentResolver bean = new PanNexacroArgumentResolver();
        return bean;
    }
    
    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
        // Nexacro ArgumentReslover 추가
        argumentResolvers.add(this.nexacroArgumentResolver());
    }
    
    /**
     * Nexacro View Resolver Bean 등록 (PlatformType.CONTENT_TYPE_XML)
     * @return
     */
    @Bean(name = "nexacroView")
    public PanNexacroView nexacroView() {
        PanNexacroView bean = new PanNexacroView();
        return bean;
    }
    
    /**
     * Nexacro View Resolver Bean 등록 (PlatformType.CONTENT_TYPE_SSV)
     * @return
     */
    @Bean(name = "nexacroSsvView")
    public PanNexacroSsvView nexacroSsvView() {
        PanNexacroSsvView bean = new PanNexacroSsvView();
        return bean;
    }
    
}
